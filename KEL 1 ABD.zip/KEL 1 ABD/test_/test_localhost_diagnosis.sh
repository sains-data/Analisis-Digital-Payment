#!/bin/bash
# Test script untuk fitur diagnosa localhost

echo "=== TEST LOCALHOST DIAGNOSIS TOOL ==="
echo "Menguji fitur diagnosa koneksi localhost..."

# Menguji status container
echo -e "\n1. Menguji status container"
container_status=$(docker-compose ps superset 2>/dev/null)
if [ $? -eq 0 ]; then
    if [[ $container_status == *"Up"* ]]; then
        echo "   ✓ Container Superset berjalan"
    else
        echo "   ✗ Container Superset tidak berjalan"
    fi
else
    echo "   ✗ Gagal melakukan docker-compose ps, cek apakah Docker berjalan"
fi

# Menguji binding port 8088
echo -e "\n2. Menguji binding port 8088"
port_check=$(netstat -tuln | grep ":8088")
if [ -n "$port_check" ]; then
    echo "   ✓ Port 8088 sudah terbind:"
    echo "     $port_check"
else
    echo "   ✗ Port 8088 tidak terbind ke aplikasi apapun"
fi

# Menguji koneksi ke localhost:8088
echo -e "\n3. Menguji koneksi ke localhost:8088"
if curl -s --head --fail http://localhost:8088/ >/dev/null; then
    echo "   ✓ Koneksi ke localhost:8088 berhasil!"
else
    echo "   ✗ Gagal terhubung ke localhost:8088"
fi

# Memeriksa file hosts
echo -e "\n4. Memeriksa file hosts"
if grep -q "127.0.0.1.*localhost" /etc/hosts; then
    echo "   ✓ Entri localhost ditemukan di file hosts"
else
    echo "   ✗ Entri localhost tidak ditemukan di file hosts!"
fi

# Memeriksa pengaturan firewall
echo -e "\n5. Memeriksa pengaturan firewall"
if command -v ufw &> /dev/null; then
    ufw_status=$(sudo ufw status | grep 8088)
    if [ -n "$ufw_status" ]; then
        echo "   ✓ Aturan firewall untuk port 8088 ditemukan"
    else
        echo "   ⚠ Aturan firewall untuk port 8088 tidak ditemukan"
    fi
elif command -v firewall-cmd &> /dev/null; then
    firewall_status=$(sudo firewall-cmd --list-ports | grep 8088)
    if [ -n "$firewall_status" ]; then
        echo "   ✓ Aturan firewall untuk port 8088 ditemukan"
    else
        echo "   ⚠ Aturan firewall untuk port 8088 tidak ditemukan"
    fi
else
    echo "   - Tidak dapat mendeteksi sistem firewall"
fi

# Memeriksa akses alternatif via 127.0.0.1
echo -e "\n6. Memeriksa akses alternatif via 127.0.0.1"
if curl -s --head --fail http://127.0.0.1:8088/ >/dev/null; then
    echo "   ✓ Koneksi ke 127.0.0.1:8088 berhasil!"
else
    echo "   ✗ Gagal terhubung ke 127.0.0.1:8088"
fi

echo -e "\n=== MENGUJI FUNGSI DIAGNOSA DI FIX-SUPERSET-LOGIN.SH ==="
echo "Untuk menjalankan diagnosa lengkap, jalankan:"
echo "./fix-superset-login.sh"
echo "Dan pilih opsi 5"
