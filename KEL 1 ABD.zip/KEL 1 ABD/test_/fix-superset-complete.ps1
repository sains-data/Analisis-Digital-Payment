# Complete fix for Superset login and data connection issues
Write-Host "=== COMPLETE SUPERSET FIX TOOLKIT ===" -ForegroundColor Cyan
Write-Host "This script fixes login issues and data connectivity in Superset" -ForegroundColor Yellow
Write-Host ""

# Step 1: Stop and remove existing containers
Write-Host "Step 1: Stopping and removing existing Superset containers..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml down
docker-compose -f docker-compose-superset-simple.yml down
docker-compose -f docker-compose-superset-official.yml down
docker rm -f superset 2>$null

# Step 2: Clean up volumes to ensure fresh start
Write-Host "Step 2: Cleaning up volumes for a fresh start..." -ForegroundColor Green
docker volume rm -f test__superset_home 2>$null

# Step 3: Run the fixed Superset container
Write-Host "Step 3: Starting Superset with fixed configuration..." -ForegroundColor Green
docker-compose -f docker-compose-superset-fixed.yml up -d

# Step 4: Wait for container to be ready
Write-Host "Step 4: Waiting for Superset container to be ready (30 seconds)..." -ForegroundColor Green
Start-Sleep -Seconds 30

# Step 5: Execute the login fix script in the container
Write-Host "Step 5: Running login fix script inside container..." -ForegroundColor Green
docker exec -it superset bash -c "chmod +x /app/superset_init/fix_login_complete.sh && /app/superset_init/fix_login_complete.sh"

# Step 6: Install dependencies for database connection
Write-Host "Step 6: Installing database connection dependencies..." -ForegroundColor Green
docker exec -it superset pip install pyhive[hive]==0.7.0 sasl==0.3.1 thrift==0.16.0 thrift_sasl==0.4.3 sqlalchemy==1.4.46

# Step 7: Restart the container to apply changes
Write-Host "Step 7: Restarting container to apply all changes..." -ForegroundColor Green
docker-compose -f docker-compose-superset-fixed.yml restart

# Step 8: Check container status
Write-Host "Step 8: Checking Superset container status..." -ForegroundColor Green
docker ps -a | Select-String "superset"

# Step 9: Verify connectivity
Write-Host "Step 9: Verifying Superset accessibility..." -ForegroundColor Green
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8088/login/" -UseBasicParsing -ErrorAction SilentlyContinue
    if ($response.StatusCode -eq 200) {
        Write-Host "Superset is accessible at http://localhost:8088" -ForegroundColor Green
    } else {
        Write-Host "Superset returned status code: $($response.StatusCode)" -ForegroundColor Yellow
    }
} catch {
    Write-Host "Could not connect to Superset yet. Please wait a bit longer." -ForegroundColor Yellow
}

Write-Host "`nSuperset should be fixed and accessible now!" -ForegroundColor Cyan
Write-Host "Access Superset at: http://localhost:8088" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
Write-Host "`nIf still not accessible, please wait 60 more seconds or try accessing in an incognito browser window" -ForegroundColor Yellow
