# Script untuk mengelola volume Superset

Write-Host "=== SUPERSET VOLUME MANAGER ===" -ForegroundColor Cyan
Write-Host ""

$option = Read-Host "Pilih opsi pengelolaan volume:
1. Cek status volume Superset
2. Reset volume Superset (hapus dan buat baru)
3. Backup volume Superset
4. Restore backup volume Superset
5. Keluar

Pilihan Anda (1-5)"

switch ($option) {
    "1" {
        Write-Host "Memeriksa status volume Superset..." -ForegroundColor Yellow
        docker volume inspect test__superset_home
    }
    "2" {
        Write-Host "Mereset volume Superset..." -ForegroundColor Yellow
        
        # Stop container agar volume tidak digunakan
        Write-Host "Menghentikan container Superset..." -ForegroundColor Gray
        docker-compose stop superset superset-init
        
        # Hapus volume
        Write-Host "Menghapus volume Superset..." -ForegroundColor Gray
        docker volume rm -f test__superset_home
        
        # Jalankan kembali container
        Write-Host "Menjalankan kembali container Superset..." -ForegroundColor Gray
        docker-compose up -d superset superset-init
        
        Write-Host "Volume Superset telah direset!" -ForegroundColor Green
        Write-Host "Tunggu 30-60 detik untuk inisialisasi lengkap" -ForegroundColor Yellow
    }
    "3" {
        $backupDir = ".\backup\superset"
        $backupFile = "superset-volume-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss').tar"
        
        # Buat direktori backup jika belum ada
        if (!(Test-Path -Path $backupDir)) {
            New-Item -ItemType Directory -Path $backupDir -Force | Out-Null
        }
        
        Write-Host "Membuat backup volume Superset..." -ForegroundColor Yellow
        
        # Buat container sementara untuk backup
        docker run --rm -v test__superset_home:/volume -v ${PWD}/backup/superset:/backup alpine tar -cf /backup/$backupFile -C /volume .
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Backup berhasil dibuat di $backupDir\$backupFile" -ForegroundColor Green
        }
        else {
            Write-Host "Backup gagal dibuat" -ForegroundColor Red
        }
    }
    "4" {
        $backupDir = ".\backup\superset"
        
        if (!(Test-Path -Path $backupDir)) {
            Write-Host "Direktori backup tidak ditemukan!" -ForegroundColor Red
            exit
        }
        
        $backupFiles = Get-ChildItem -Path $backupDir -Filter "*.tar" | Select-Object -ExpandProperty Name
        
        if ($backupFiles.Count -eq 0) {
            Write-Host "Tidak ada file backup yang ditemukan!" -ForegroundColor Red
            exit
        }
        
        Write-Host "File backup yang tersedia:" -ForegroundColor Yellow
        for ($i=0; $i -lt $backupFiles.Count; $i++) {
            Write-Host "$($i+1). $($backupFiles[$i])" -ForegroundColor White
        }
        
        $selection = Read-Host "Pilih nomor file backup untuk restore (1-$($backupFiles.Count))"
        $index = [int]$selection - 1
        
        if ($index -lt 0 -or $index -ge $backupFiles.Count) {
            Write-Host "Pilihan tidak valid!" -ForegroundColor Red
            exit
        }
        
        $selectedFile = $backupFiles[$index]
        
        Write-Host "Merestorasi volume Superset dari $selectedFile..." -ForegroundColor Yellow
        
        # Stop container agar volume tidak digunakan
        Write-Host "Menghentikan container Superset..." -ForegroundColor Gray
        docker-compose stop superset superset-init
        
        # Hapus volume
        Write-Host "Menghapus volume Superset..." -ForegroundColor Gray
        docker volume rm -f test__superset_home
        
        # Buat volume baru
        Write-Host "Membuat volume baru..." -ForegroundColor Gray
        docker volume create test__superset_home
        
        # Restore dari backup
        docker run --rm -v test__superset_home:/volume -v ${PWD}/backup/superset:/backup alpine sh -c "tar -xf /backup/$selectedFile -C /volume"
        
        if ($LASTEXITCODE -eq 0) {
            Write-Host "Restore berhasil!" -ForegroundColor Green
        }
        else {
            Write-Host "Restore gagal!" -ForegroundColor Red
        }
        
        # Jalankan kembali container
        Write-Host "Menjalankan kembali container Superset..." -ForegroundColor Gray
        docker-compose up -d superset superset-init
    }
    "5" {
        Write-Host "Keluar dari volume manager." -ForegroundColor Gray
        exit
    }
    default {
        Write-Host "Pilihan tidak valid." -ForegroundColor Red
    }
}

Write-Host ""
Write-Host "Operasi selesai!" -ForegroundColor Cyan
