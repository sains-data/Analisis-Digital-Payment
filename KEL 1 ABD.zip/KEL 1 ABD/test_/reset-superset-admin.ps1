# Reset Superset Admin credentials

Write-Host "Resetting Superset Admin credentials..." -ForegroundColor Green

# Vérifiez si Superset est en cours d'exécution
Write-Host "Checking if Superset container is running..." -ForegroundColor Yellow
$containerStatus = docker-compose ps superset
if ($containerStatus -notmatch "Up") {
    Write-Host "Superset container is not running. Starting it now..." -ForegroundColor Red
    docker-compose up -d superset
    
    # Wait a bit for container to start fully
    Write-Host "Waiting for container to start (30 seconds)..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
}

# DB upgrade to make sure schema is updated
Write-Host "Upgrading database schema..." -ForegroundColor Yellow
docker-compose exec -T superset superset db upgrade

# Connect to running Superset container and reset admin
Write-Host "Creating admin user..." -ForegroundColor Yellow
docker-compose exec -T superset superset fab create-admin `
    --username admin `
    --firstname Superset `
    --lastname Admin `
    --email admin@superset.com `
    --password admin `
    --force

Write-Host "Syncing permissions..." -ForegroundColor Yellow
docker-compose exec -T superset superset init

# Test if Superset API is accessible
Write-Host "Testing connection to Superset API..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8088/api/v1/health" -Method GET -TimeoutSec 10 -ErrorAction SilentlyContinue
    if ($response) {
        Write-Host "Connection to Superset API successful!" -ForegroundColor Green
    }
}
catch {
    Write-Host "Could not connect to Superset API. Container may still be starting up." -ForegroundColor Yellow
    Write-Host "You can still try to login after waiting a minute." -ForegroundColor Yellow
}

Write-Host "Admin credentials have been reset to:" -ForegroundColor Green
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
Write-Host "Access dashboard at: http://localhost:8088" -ForegroundColor White
