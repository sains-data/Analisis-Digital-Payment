# Superset Connection Troubleshooter
Write-Host "=== SUPERSET CONNECTION TROUBLESHOOTER ===" -ForegroundColor Cyan
Write-Host "This script diagnoses and fixes Superset connectivity issues" -ForegroundColor Yellow
Write-Host ""

# Function to check if a URL is accessible
function Test-URL {
    param (
        [string]$URL
    )
    
    try {
        $response = Invoke-WebRequest -Uri $URL -UseBasicParsing -TimeoutSec 5 -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

# Check Superset container status
Write-Host "Checking Superset container status..." -ForegroundColor Green
$containerStatus = docker ps -a | Select-String "superset"
Write-Host $containerStatus -ForegroundColor Gray

# Check if container is running
$isRunning = docker ps | Select-String "superset"
if (-not $isRunning) {
    Write-Host "Superset container is not running! Starting it now..." -ForegroundColor Red
    docker start superset
    Write-Host "Waiting 30 seconds for container to start..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
}

# Check container logs for errors
Write-Host "`nChecking container logs for errors..." -ForegroundColor Green
$logs = docker logs --tail 50 superset 2>&1
$errors = $logs | Select-String "error|exception|traceback" -CaseSensitive:$false
if ($errors) {
    Write-Host "Found errors in logs:" -ForegroundColor Red
    $errors | ForEach-Object { Write-Host $_ -ForegroundColor Gray }
} else {
    Write-Host "No critical errors found in recent logs" -ForegroundColor Green
}

# Check network connectivity
Write-Host "`nTesting network connectivity..." -ForegroundColor Green
$supersetURL = "http://localhost:8088"
$isAccessible = Test-URL -URL $supersetURL

if ($isAccessible) {
    Write-Host "Superset is accessible at $supersetURL" -ForegroundColor Green
} else {
    Write-Host "Cannot access Superset at $supersetURL" -ForegroundColor Red
    
    # Check if port is being used
    $portCheck = netstat -ano | Select-String "8088"
    Write-Host "Port 8088 status:" -ForegroundColor Yellow
    Write-Host $portCheck -ForegroundColor Gray
    
    # Check container port mapping
    Write-Host "Container port mapping:" -ForegroundColor Yellow
    docker port superset
    
    # Attempt to fix port binding
    Write-Host "Attempting to fix port binding..." -ForegroundColor Yellow
    docker-compose -f docker-compose-superset-fixed.yml down
    Start-Sleep -Seconds 5
    docker-compose -f docker-compose-superset-fixed.yml up -d
    
    Write-Host "Waiting 30 seconds for container to restart..." -ForegroundColor Yellow
    Start-Sleep -Seconds 30
}

# Check if login works by checking for login page
$loginCheck = Invoke-WebRequest -Uri "http://localhost:8088/login/" -UseBasicParsing -ErrorAction SilentlyContinue
if ($loginCheck -and $loginCheck.StatusCode -eq 200) {
    Write-Host "`nLogin page is accessible" -ForegroundColor Green
} else {
    Write-Host "`nLogin page is not accessible" -ForegroundColor Red
    
    # Fix admin credentials
    Write-Host "Attempting to fix admin credentials..." -ForegroundColor Yellow
    docker exec -i superset bash -c "superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin"
    docker exec -i superset bash -c "superset init"
}

# Final check for database connectivity
Write-Host "`nChecking database connectivity..." -ForegroundColor Green
docker exec -i superset bash -c "superset db check"

Write-Host "`nTroubleshooting complete!" -ForegroundColor Cyan
Write-Host "If Superset is still not accessible, try:" -ForegroundColor White
Write-Host "1. Wait a few more minutes for it to fully initialize" -ForegroundColor White
Write-Host "2. Access using an incognito browser window" -ForegroundColor White
Write-Host "3. Clear your browser cache" -ForegroundColor White
Write-Host "`nLogin with:" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
