﻿# check-csv-config.py
from superset.app import create_app
app = create_app()
with app.app_context():
    print('Checking CSV Upload Configuration:')
    csv_enabled = app.config.get('FEATURE_FLAGS', {}).get('ALLOW_CSV_UPLOAD', False)
    file_upload = app.config.get('ALLOW_FILE_UPLOAD', False)
    allowed_extensions = app.config.get('ALLOWED_FILE_EXTENSIONS', set())
    
    print(f'ALLOW_CSV_UPLOAD enabled: {csv_enabled}')
    print(f'ALLOW_FILE_UPLOAD enabled: {file_upload}')
    print(f'ALLOWED_FILE_EXTENSIONS: {allowed_extensions}')
    
    if csv_enabled and file_upload:
        print('CSV upload feature is properly configured!')
    else:
        print('CSV upload feature is NOT properly configured!')
