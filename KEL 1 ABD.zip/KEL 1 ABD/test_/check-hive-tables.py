﻿# check-hive-tables.py
try:
    from pyhive import hive
    import pandas as pd
    
    print('Connecting to Hive server...')
    conn = hive.Connection(host='namenode', port=10000, username='hive')
    print('Connection successful!')
    
    cursor = conn.cursor()
    print('\nListing available tables:')
    cursor.execute('SHOW TABLES')
    tables = cursor.fetchall()
    
    if not tables:
        print('No tables found in Hive.')
    else:
        print(f'Found {len(tables)} tables:')
        for table in tables:
            print(f'- {table[0]}')
    
    # Check specifically for digital_payments_data table
    print('\nChecking for digital_payments_data table:')
    cursor.execute("SHOW TABLES LIKE 'digital_payments_data'")
    if cursor.fetchone():
        print('digital_payments_data table exists!')
        
        # Check table structure
        print('\nTable structure:')
        cursor.execute('DESCRIBE digital_payments_data')
        columns = cursor.fetchall()
        for col in columns:
            print(f'- {col[0]}: {col[1]}')
            
        # Show sample data
        print('\nSample data (first 5 rows):')
        cursor.execute('SELECT * FROM digital_payments_data LIMIT 5')
        rows = cursor.fetchall()
        column_names = [desc[0] for desc in cursor.description]
        df = pd.DataFrame(rows, columns=column_names)
        print(df)
    else:
        print('digital_payments_data table does NOT exist!')
    
    conn.close()
    
except Exception as e:
    print(f'Error: {e}')
