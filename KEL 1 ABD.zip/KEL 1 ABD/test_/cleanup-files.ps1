# Script untuk membersihkan file-file duplikat
# filepath: c:\Users\Fadhil\Downloads\test_\test_\cleanup-files.ps1

# Buat direktori backup terlebih dahulu
Write-Host "Membuat direktori backup..." -ForegroundColor Yellow
New-Item -Path "./backup_files" -ItemType Directory -Force | Out-Null

# Backup file terlebih dahulu
Write-Host "Backup file-file yang akan dihapus..." -ForegroundColor Yellow
Copy-Item -Path "./fix-login-specific.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-login-issue.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-login-superset.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-login-superset.sh" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-superset-sasl.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-superset-sasl.sh" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-superset-standalone.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-superset-standalone.sh" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./rebuild-and-run-superset.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./rebuild-superset.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./rebuild-superset.sh" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./reset-superset.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./test-superset-connection.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./total-superset-fix.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./total-superset-fix.sh" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./fix-auth-only.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./update-superset-command.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue
Copy-Item -Path "./superset-rebuild-guide.ps1" -Destination "./backup_files/" -ErrorAction SilentlyContinue

# Hapus file yang tidak diperlukan
Write-Host "Menghapus file-file duplikat..." -ForegroundColor Yellow
Remove-Item -Path "./fix-login-specific.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-login-issue.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-login-superset.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-login-superset.sh" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-superset-sasl.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-superset-sasl.sh" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-superset-standalone.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-superset-standalone.sh" -ErrorAction SilentlyContinue
Remove-Item -Path "./rebuild-and-run-superset.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./rebuild-superset.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./rebuild-superset.sh" -ErrorAction SilentlyContinue
Remove-Item -Path "./reset-superset.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./test-superset-connection.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./total-superset-fix.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./total-superset-fix.sh" -ErrorAction SilentlyContinue
Remove-Item -Path "./fix-auth-only.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./update-superset-command.ps1" -ErrorAction SilentlyContinue
Remove-Item -Path "./superset-rebuild-guide.ps1" -ErrorAction SilentlyContinue

Write-Host "File-file duplikat telah dibackup ke ./backup_files dan dihapus dari direktori utama" -ForegroundColor Green
