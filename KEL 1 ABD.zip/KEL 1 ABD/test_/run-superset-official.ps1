# Script untuk menjalankan Superset menggunakan image resmi Apache Superset
# Script ini menghindari proses build image Superset kustom

Write-Host "=== MENJALANKAN APACHE SUPERSET DENGAN IMAGE RESMI ===" -ForegroundColor Cyan
Write-Host "Script ini akan menggunakan image resmi Apache Superset dan menghindari build kustom" -ForegroundColor Yellow
Write-Host ""

# Step 1: Stop dan hapus container Superset yang ada
Write-Host "Step 1: Membersihkan container Superset..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml down
docker rm -f superset 2>$null

# Step 2: Edit docker-compose-superset.yml untuk menggunakan image resmi
Write-Host "Step 2: Membuat file konfigurasi Superset dengan image resmi..." -ForegroundColor Green

$supersetComposeContent = @"
version: '3.7'

services:
  superset:
    image: apache/superset:latest
    container_name: superset
    restart: always
    ports:
      - "8088:8088"
    environment:
      - SUPERSET_SECRET_KEY=your_secret_key_here
      - SUPERSET_LOAD_EXAMPLES=false
      - PYTHONPATH=/app/pythonpath:/app/superset_init
      - WTF_CSRF_ENABLED=false
      - FLASK_ENV=development
      - SUPERSET_WEBSERVER_ADDRESS=0.0.0.0
    volumes:
      - ./superset/superset_config.py:/app/pythonpath/superset_config.py
      - ./superset/init:/app/superset_init
      - superset_home:/app/superset_home
    command: >
      bash -c "
        superset db upgrade &&
        superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force &&
        superset init &&
        gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 'superset.app:create_app()'
      "
    networks:
      - hadoop
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8088"]
      interval: 30s
      retries: 5
      start_period: 60s
      timeout: 30s

volumes:
  superset_home:

networks:
  hadoop:
    external: true
"@

$supersetComposeContent | Out-File -FilePath "./docker-compose-superset-official.yml" -Encoding UTF8 -Force

# Step 3: Install fix_dependencies.sh script yang diperlukan
Write-Host "Step 3: Menyiapkan script instalasi dependensi..." -ForegroundColor Green

$fixDependenciesContent = @"
#!/bin/bash
echo "Installing required dependencies..."
pip install flask-cors==3.0.10
pip install psycopg2-binary
pip install pyathena
pip install pyhive[hive]==0.7.0
pip install sasl==0.3.1 thrift==0.16.0 thrift_sasl==0.4.3
pip install sqlalchemy==1.4.46
pip install werkzeug==2.0.3
pip install flask==2.0.3
pip install flask-wtf==0.15.1
pip install wtforms==2.3.3

echo "Fixing permissions..."
chmod -R 777 /app/superset_home

echo "Running DB upgrade..."
superset db upgrade

echo "Creating admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

echo "Initializing..."
superset init

echo "All fixes applied!"
"@

$fixDependenciesContent | Out-File -FilePath "./superset/init/fix_dependencies_official.sh" -Encoding UTF8 -Force

# Step 4: Make sure network exists
Write-Host "Step 4: Memastikan network hadoop tersedia..." -ForegroundColor Green
docker network inspect hadoop >$null 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "  Membuat network hadoop..." -ForegroundColor Gray
    docker network create hadoop
} else {
    Write-Host "  Network hadoop sudah ada" -ForegroundColor Gray
}

# Step 5: Start Superset with official image
Write-Host "Step 5: Menjalankan Superset dengan image resmi..." -ForegroundColor Green
docker-compose -f docker-compose-superset-official.yml up -d
Write-Host "  Menunggu Superset siap (30 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 30

# Step 6: Run fix_dependencies in the container
Write-Host "Step 6: Menginstall dependensi tambahan di container..." -ForegroundColor Green
docker-compose -f docker-compose-superset-official.yml exec -T superset chmod +x /app/superset_init/fix_dependencies_official.sh
docker-compose -f docker-compose-superset-official.yml exec -T superset /app/superset_init/fix_dependencies_official.sh

Write-Host "`nApache Superset telah berhasil dijalankan dengan image resmi!" -ForegroundColor Cyan
Write-Host "Akses Superset di http://localhost:8088 atau http://127.0.0.1:8088" -ForegroundColor White
Write-Host "  - Username: admin" -ForegroundColor White
Write-Host "  - Password: admin" -ForegroundColor White
Write-Host "CATATAN: Jika mengalami masalah login, silakan lihat PANDUAN_TROUBLESHOOTING.md" -ForegroundColor Yellow
