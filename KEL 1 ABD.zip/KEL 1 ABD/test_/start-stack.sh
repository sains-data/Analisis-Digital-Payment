#!/bin/bash
# Script to start the entire data analysis stack

echo "Starting Hadoop, Spark, and Superset stack..."

# Start all services
docker-compose up -d

echo "Waiting for services to be ready..."
sleep 30

# Check if HDFS is ready
echo "Checking HDFS status..."
docker-compose exec namenode hdfs dfsadmin -report

# Check Spark status
echo "Checking Spark status..."
docker-compose exec spark-master curl -s http://localhost:8080/json/ | grep status  # Masih menggunakan port 8080 di dalam container

# Upload data to HDFS
echo "Uploading data to HDFS..."
docker-compose exec namenode bash -c "chmod +x /data/prepare_hdfs_data.sh && /data/prepare_hdfs_data.sh"

echo "Data stack is now running!"
echo ""
echo "Access points:"
echo "- HDFS UI: http://localhost:9870"
echo "- Spark UI: http://localhost:8081"
echo "- Jupyter Notebook: http://localhost:8888"
echo "- Superset: http://localhost:8088"
echo "- Resource Manager: http://localhost:8089"
echo ""
echo "For Jupyter, please check the logs for the token:"
echo "docker-compose logs jupyter | grep token"
