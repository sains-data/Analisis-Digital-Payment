from pyspark.sql import SparkSession

# Membuat Spark Session dengan dukungan untuk Hive
spark = SparkSession.builder \
    .appName("Create Credit Card Table") \
    .master("spark://spark-master:7077") \
    .config("spark.sql.warehouse.dir", "/user/hive/warehouse") \
    .config("spark.sql.catalogImplementation", "hive") \
    .enableHiveSupport() \
    .getOrCreate()

# Membaca file CSV
df = spark.read.option("header", "true") \
    .option("inferSchema", "true") \
    .csv("/user/hive/warehouse/DataFixABD.csv")

# Ganti nama kolom untuk menghilangkan spasi
for column in df.columns:
    df = df.withColumnRenamed(column, column.replace(" ", "_"))

# Simpan sebagai tabel Hive
df.write.mode("overwrite").saveAsTable("credit_card_data")

print("Table credit_card_data created successfully!")
spark.stop()
