from pyhive import hive
try:
    conn = hive.Connection(host='namenode', port=10000, username='hive')
    cursor = conn.cursor()
    cursor.execute('SHOW TABLES')
    tables = cursor.fetchall()
    print("Tabel yang tersedia di Hive:")
    for table in tables:
        print(f"- {table[0]}")
        
    # Cek tabel digital_payments_data
    cursor.execute("DESCRIBE digital_payments_data")
    columns = cursor.fetchall()
    if columns:
        print("\nTabel digital_payments_data ditemukan dengan kolom-kolom:")
        for col in columns:
            print(f"- {col[0]} ({col[1]})")
    else:
        print("\nTabel digital_payments_data tidak ditemukan")
    conn.close()
    print("\nKoneksi ke Hive berhasil!")
except Exception as e:
    print(f"Error saat menghubungkan ke Hive: {e}")
