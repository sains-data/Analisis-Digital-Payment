#!/usr/bin/env pwsh
# Test script untuk fitur diagnosa localhost

Write-Host "=== TEST LOCALHOST DIAGNOSIS TOOL ===" -ForegroundColor Cyan
Write-Host "Menguji fitur diagnosa koneksi localhost..." -ForegroundColor Yellow

# Function untuk menjalankan test
function Test-LocalhostConnection {
    Write-Host "`n1. Menguji status container" -ForegroundColor Gray
    $containerStatus = docker-compose ps superset 2>$null
    if ($LASTEXITCODE -eq 0) {
        if ($containerStatus -match "Up") {
            Write-Host "   ✓ Container Superset berjalan" -ForegroundColor Green
        } else {
            Write-Host "   ✗ Container Superset tidak berjalan" -ForegroundColor Red
        }
    } else {
        Write-Host "   ✗ Gagal melakukan docker-compose ps, cek apakah Docker berjalan" -ForegroundColor Red
    }

    Write-Host "`n2. Menguji binding port 8088" -ForegroundColor Gray
    $portCheck = netstat -ano | findstr ":8088"
    if ($portCheck) {
        Write-Host "   ✓ Port 8088 sudah terbind:" -ForegroundColor Green
        Write-Host "     $portCheck"
    } else {
        Write-Host "   ✗ Port 8088 tidak terbind ke aplikasi apapun" -ForegroundColor Red
    }

    Write-Host "`n3. Menguji koneksi ke localhost:8088" -ForegroundColor Gray
    try {
        $testConnection = Invoke-WebRequest -Uri "http://localhost:8088/" -Method Head -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($testConnection.StatusCode -eq 200) {
            Write-Host "   ✓ Koneksi ke localhost:8088 berhasil!" -ForegroundColor Green
        } else {
            Write-Host "   ⚠ Status code respons: $($testConnection.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "   ✗ Gagal terhubung ke localhost:8088: $($_.Exception.Message)" -ForegroundColor Red
    }

    Write-Host "`n4. Memeriksa file hosts" -ForegroundColor Gray
    $hostsContent = Get-Content -Path "$env:windir\System32\drivers\etc\hosts"
    if ($hostsContent -match "localhost") {
        Write-Host "   ✓ Entri localhost ditemukan di file hosts" -ForegroundColor Green
    } else {
        Write-Host "   ✗ Entri localhost tidak ditemukan di file hosts!" -ForegroundColor Red
    }

    Write-Host "`n5. Memeriksa pengaturan firewall" -ForegroundColor Gray
    $firewallRule = Get-NetFirewallRule -DisplayName "Superset Dashboard 8088" -ErrorAction SilentlyContinue
    if ($firewallRule) {
        Write-Host "   ✓ Aturan firewall untuk Superset ditemukan" -ForegroundColor Green 
    } else {
        Write-Host "   ⚠ Aturan firewall untuk Superset tidak ditemukan" -ForegroundColor Yellow
    }
    
    Write-Host "`n6. Memeriksa akses alternatif via 127.0.0.1" -ForegroundColor Gray
    try {
        $testConnection = Invoke-WebRequest -Uri "http://127.0.0.1:8088/" -Method Head -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($testConnection.StatusCode -eq 200) {
            Write-Host "   ✓ Koneksi ke 127.0.0.1:8088 berhasil!" -ForegroundColor Green
        } else {
            Write-Host "   ⚠ Status code respons: $($testConnection.StatusCode)" -ForegroundColor Yellow
        }
    } catch {
        Write-Host "   ✗ Gagal terhubung ke 127.0.0.1:8088: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Jalankan test
Test-LocalhostConnection

Write-Host "`n=== MENGUJI FUNGSI DIAGNOSA DI FIX-SUPERSET-LOGIN.PS1 ===" -ForegroundColor Cyan
Write-Host "Untuk menjalankan diagnosa lengkap, jalankan:"
Write-Host ".\fix-superset-login.ps1" -ForegroundColor Yellow
Write-Host "Dan pilih opsi 5" -ForegroundColor Yellow
