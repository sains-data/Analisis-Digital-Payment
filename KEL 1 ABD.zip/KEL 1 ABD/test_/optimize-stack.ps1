# Script untuk mengoptimalkan stack big data (HDFS, Spark, Superset)

Write-Host "=== OPTIMASI STACK BIG DATA ===" -ForegroundColor Cyan
Write-Host "Memperbaiki dan mengoptimalkan lingkungan HDFS, Spark, dan Superset" -ForegroundColor Yellow
Write-Host ""

# Step 1: Build custom Superset image dengan dependensi yang benar
Write-Host "Step 1: Membangun image Superset dengan dependensi yang benar..." -ForegroundColor Green
docker build -t custom-superset:fixed -f Dockerfile.superset .

# Step 2: Restart stack dengan urutan yang benar
Write-Host "Step 2: Restart stack dengan urutan yang benar..." -ForegroundColor Green

# Stop stack
Write-Host "  Menghentikan semua services..." -ForegroundColor Gray
docker-compose -f docker-compose-superset.yml down
docker-compose down
docker rm -f superset 2>$null

# Ensure volumes are properly managed
Write-Host "  Memastikan volume Superset dalam keadaan baik..." -ForegroundColor Gray
docker volume inspect test__superset_home 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "  Volume superset_home tidak ditemukan, membuat ulang..." -ForegroundColor Yellow
    docker volume create test__superset_home
} else {
    Write-Host "  Volume superset_home ditemukan, melanjutkan..." -ForegroundColor Green
}

# Start stack in correct order
Write-Host "  Menjalankan Hadoop components..." -ForegroundColor Gray
docker-compose up -d namenode datanode

# Wait for Hadoop to be ready
Write-Host "  Menunggu HDFS siap (15 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 15

# Start Spark
Write-Host "  Menjalankan Spark services..." -ForegroundColor Gray
docker-compose up -d spark-master spark-worker-1

# Wait for Spark to be ready
Write-Host "  Menunggu Spark siap (15 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 15

# Start Superset
Write-Host "  Menjalankan Superset..." -ForegroundColor Gray
docker network ls | Select-String "hadoop" | Out-Null
if ($LASTEXITCODE -ne 0) {
    Write-Host "  Network hadoop tidak ditemukan, membuat network..." -ForegroundColor Yellow
    docker network create hadoop
}
docker-compose -f docker-compose-superset.yml up -d

# Wait for Superset to be ready
Write-Host "  Menunggu Superset siap (30 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 30

# Step 3: Reset Superset admin credentials
Write-Host "Step 3: Reset kredensial admin Superset..." -ForegroundColor Green
docker-compose exec -T superset superset db upgrade
docker-compose exec -T superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force
docker-compose exec -T superset superset init

# Step 4: Verify everything is running
Write-Host "Step 4: Verifikasi semua container berjalan..." -ForegroundColor Green
docker-compose ps
docker-compose -f docker-compose-superset.yml ps

Write-Host "`nStack Big Data telah dioptimasi!" -ForegroundColor Cyan
Write-Host "  HDFS NameNode UI  : http://localhost:9870" -ForegroundColor White
Write-Host "  Spark Master UI  : http://localhost:8080" -ForegroundColor White
Write-Host "  Superset         : http://localhost:8088" -ForegroundColor White
Write-Host "    - Username: admin" -ForegroundColor White
Write-Host "    - Password: admin" -ForegroundColor White
Write-Host ""
Write-Host "CATATAN PENTING:" -ForegroundColor Magenta
Write-Host "1. Jika Superset masih tidak dapat diakses via localhost, gunakan http://127.0.0.1:8088" -ForegroundColor Yellow
Write-Host "2. Untuk koneksi Hive di Superset, gunakan: hive://hive@spark-master:10000/default" -ForegroundColor Yellow
Write-Host "3. Jika login masih bermasalah, gunakan mode incognito browser" -ForegroundColor Yellow
