# Enhanced Diagnosis for Superset Connection Issues
Write-Host "=== ENHANCED SUPERSET CONNECTION DIAGNOSIS ===" -ForegroundColor Cyan

# 1. Check Docker status
Write-Host "1. Checking Docker status..." -ForegroundColor Yellow
try {
    $dockerVersion = docker --version
    Write-Host "   Docker is running: $dockerVersion" -ForegroundColor Green
} catch {
    Write-Host "   ERROR: Docker is not running or not installed!" -ForegroundColor Red
    Write-Host "   Please make sure Docker Desktop is running." -ForegroundColor Red
    exit
}

# 2. Check Docker Compose version
Write-Host "`n2. Checking Docker Compose..." -ForegroundColor Yellow
try {
    $composeVersion = docker-compose --version
    Write-Host "   Docker Compose is installed: $composeVersion" -ForegroundColor Green
} catch {
    Write-Host "   ERROR: Docker Compose is not installed or not in PATH!" -ForegroundColor Red
    exit
}

# 3. Check if Superset container exists
Write-Host "`n3. Checking Superset container..." -ForegroundColor Yellow
$containerExists = docker ps -a --format "{{.Names}}" | Select-String "superset"
if ($containerExists) {
    Write-Host "   Superset container exists." -ForegroundColor Green
    
    # Check container status
    $containerRunning = docker ps --format "{{.Names}}" | Select-String "superset"
    if ($containerRunning) {
        Write-Host "   Superset container is RUNNING." -ForegroundColor Green
    } else {
        Write-Host "   Superset container is NOT RUNNING!" -ForegroundColor Red
        
        # Get container status
        $containerStatus = docker inspect --format="{{.State.Status}}" superset 2>$null
        Write-Host "   Container status: $containerStatus" -ForegroundColor Yellow
        
        # Check if the container is restarting
        $restartCount = docker inspect --format="{{.RestartCount}}" superset 2>$null
        Write-Host "   Container restart count: $restartCount" -ForegroundColor Yellow
        
        # Show container logs
        Write-Host "`n   Container logs (last 20 lines):" -ForegroundColor Yellow
        docker logs --tail 20 superset
        
        # Check for specific errors related to SASL or authentication
        Write-Host "`n   Checking for specific errors in logs..." -ForegroundColor Yellow
        $saslErrors = docker logs superset 2>&1 | Select-String -Pattern "sasl|authentication|login|password|ImportError|ModuleNotFoundError|thrift|connection refused"
        if ($saslErrors) {
            Write-Host "   Found potential issues:" -ForegroundColor Red
            foreach ($error in $saslErrors) {
                Write-Host "   - $error" -ForegroundColor Red
            }
        } else {
            Write-Host "   No specific authentication errors found in logs." -ForegroundColor Green
        }
        
        # Ask to start the container
        $startContainer = Read-Host "`n   Do you want to start the container? (y/n)"
        if ($startContainer -eq "y") {
            docker start superset
        }
    }
} else {
    Write-Host "   Superset container does not exist!" -ForegroundColor Red
    Write-Host "   Run 'docker-compose up -d superset' to create and start the container." -ForegroundColor Yellow
}

# 4. Check network configuration
Write-Host "`n4. Checking network configuration..." -ForegroundColor Yellow
$networks = docker network ls --format "{{.Name}}" | Select-String "hadoop|superset"
Write-Host "   Available networks: $networks" -ForegroundColor Green

# 5. Check port bindings
Write-Host "`n5. Checking port bindings..." -ForegroundColor Yellow
$portBindings = docker port superset 2>$null
if ($portBindings) {
    Write-Host "   Port bindings for Superset:" -ForegroundColor Green
    Write-Host "   $portBindings"
    
    # Check if 8088 is bound
    if ($portBindings -match "8088") {
        Write-Host "   Port 8088 is properly bound." -ForegroundColor Green
    } else {
        Write-Host "   Port 8088 is NOT bound to the container!" -ForegroundColor Red
    }
} else {
    Write-Host "   No port bindings found for Superset container." -ForegroundColor Red
}

# 6. Check localhost system configuration
Write-Host "`n6. Checking localhost configuration..." -ForegroundColor Yellow
try {
    $hostsFile = Get-Content -Path "$env:windir\System32\drivers\etc\hosts"
    $localhostEntry = $hostsFile | Select-String "localhost"
    if ($localhostEntry) {
        Write-Host "   Localhost entry found in hosts file: $localhostEntry" -ForegroundColor Green
    } else {
        Write-Host "   No localhost entry found in hosts file!" -ForegroundColor Red
        Write-Host "   Consider adding '127.0.0.1 localhost' to your hosts file." -ForegroundColor Yellow
    }
} catch {
    Write-Host "   Could not read hosts file. Run as administrator to check hosts file." -ForegroundColor Red
}

# 7. Test TCP connection to port 8088
Write-Host "`n7. Testing direct TCP connection to port 8088..." -ForegroundColor Yellow
try {
    $tcpClient = New-Object System.Net.Sockets.TcpClient
    $connection = $tcpClient.BeginConnect("localhost", 8088, $null, $null)
    $wait = $connection.AsyncWaitHandle.WaitOne(1000, $false)
    
    if ($wait -and $tcpClient.Connected) {
        Write-Host "   TCP connection to localhost:8088 SUCCEEDED." -ForegroundColor Green
        $tcpClient.Close()
    } else {
        Write-Host "   TCP connection to localhost:8088 FAILED!" -ForegroundColor Red
        Write-Host "   Port 8088 is not accepting connections." -ForegroundColor Red
        $tcpClient.Close()
    }
} catch {
    Write-Host "   Error testing TCP connection: $_" -ForegroundColor Red
}

# 8. Suggest solutions
Write-Host "`n=== SUGGESTED SOLUTIONS ===" -ForegroundColor Cyan
Write-Host "If you're still having issues, try these steps:" -ForegroundColor Yellow
Write-Host "1. Restart Docker Desktop completely" -ForegroundColor White
Write-Host "2. Run the following commands:" -ForegroundColor White
Write-Host "   docker-compose down" -ForegroundColor Gray
Write-Host "   docker-compose up -d" -ForegroundColor Gray
Write-Host "3. If container is restarting repeatedly, check logs:" -ForegroundColor White
Write-Host "   docker-compose logs superset" -ForegroundColor Gray
Write-Host "4. Try accessing using 127.0.0.1:8088 instead of localhost:8088" -ForegroundColor White
Write-Host "5. Check if another application is using port 8088:" -ForegroundColor White
Write-Host "   netstat -ano | findstr :8088" -ForegroundColor Gray
Write-Host "6. Ensure docker-compose.yml has proper port mapping:" -ForegroundColor White
Write-Host "   - 8088:8088" -ForegroundColor Gray
