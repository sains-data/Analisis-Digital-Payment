# Analisis Data Kartu Kredit dengan Hadoop, Spark, dan Superset

Proyek ini mengintegrasikan ekosistem big data untuk analisis data transaksi kartu kredit, mulai dari penyimpanan data di HDFS, pemrosesan dengan Spark, hingga visualisasi interaktif dengan Apache Superset.

## Arsitektur Sistem

```
┌───────────┐     ┌───────────┐     ┌───────────┐     ┌───────────┐
│           │     │           │     │           │     │           │
│   HDFS    │ ──> │   Spark   │ ──> │   Hive    │ ──> │  Superset │
│           │     │           │     │           │     │           │
└───────────┘     └───────────┘     └───────────┘     └───────────┘
  Penyimpanan       Processing       Warehousing       Visualisasi
```

## Komponen Sistem

1. **HDFS**: Hadoop Distributed File System untuk penyimpanan data
2. **Spark**: Framework pemrosesan data untuk analisis dan transformasi
3. **Hive**: Data warehouse untuk akses SQL ke data
4. **Superset**: Visualisasi data dan dashboard interaktif

## Petunjuk Penggunaan

### 1. Memulai Seluruh Sistem

```bash
# Start seluruh sistem dengan Docker Compose
docker-compose up -d
```

### 2. Persiapan Data

```bash
# Menjalankan script untuk menyiapkan data di HDFS
docker-compose exec namenode bash /data/prepare_hdfs_data.sh
```

### 3. Akses ke Berbagai Layanan

- **HDFS UI**: http://localhost:9870
- **Spark UI**: http://localhost:8081
- **Jupyter Notebook**: http://localhost:8888
- **Superset Dashboard**: http://localhost:8088

### 4. Menggunakan Jupyter Notebooks

Berikut notebook yang tersedia:
1. `credit_card_analysis.ipynb` - Analisis data kartu kredit dengan Spark
2. `spark_sql_insights.ipynb` - Analisis menggunakan Spark SQL
3. `prepare_data_for_superset.ipynb` - Persiapan data untuk Superset
4. `spark_superset_integration.ipynb` - Penjelasan integrasi Spark dan Superset

### 5. Akses Superset

1. Buka browser dan akses http://localhost:8080
2. Login dengan kredensial berikut:
   - Username: admin
   - Password: admin
3. Pilih dashboard "Credit Card Transaction Analysis" untuk melihat visualisasi

## Struktur Direktori

```
.
├── airflow/
│   └── dags/
├── config/
│   ├── hadoop/
│   └── spark/
├── data/
│   └── DataFixABD.csv
├── notebooks/
│   ├── credit_card_analysis.ipynb
│   ├── prepare_data_for_superset.ipynb
│   └── spark_superset_integration.ipynb
├── spark/
│   ├── apps/
│   └── data/
└── superset/
    ├── init/
    └── superset_config.py
```

## Visualisasi yang Tersedia di Superset

1. **Monthly Transaction Trends**: Tren bulanan nilai transaksi kartu kredit
2. **Daily Transaction Patterns**: Pola transaksi berdasarkan hari dalam seminggu
3. **Outlier Analysis**: Deteksi transaksi tidak normal
4. **Transaction Metrics Correlation**: Korelasi antar metrik nilai transaksi

## Troubleshooting

Jika mengalami masalah, coba langkah berikut:

1. Restart layanan tertentu:
   ```bash
   docker-compose restart [service-name]
   ```

2. Periksa log:
   ```bash
   docker-compose logs [service-name]
   ```

3. Pastikan data sudah diupload ke HDFS:
   ```bash
   docker-compose exec namenode hdfs dfs -ls /data/credit-card-data/
   ```

4. Periksa koneksi Superset ke Hive:
   ```bash
   docker-compose exec superset superset db-connections
   ```
