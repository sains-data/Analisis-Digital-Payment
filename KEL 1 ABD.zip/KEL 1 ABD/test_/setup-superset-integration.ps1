# Script untuk setup integrasi data ke Superset

Write-Host "=== SETUP INTEGRASI DATA UNTUK SUPERSET ===" -ForegroundColor Cyan
Write-Host ""

# Step 1: Verify HDFS is running
Write-Host "Step 1: Verifikasi HDFS dan data..." -ForegroundColor Green
docker-compose exec -T namenode hdfs dfs -ls /

# Step 2: Prepare HDFS data
Write-Host "Step 2: Mempersiapkan data di HDFS..." -ForegroundColor Green
docker-compose exec -T namenode bash -c "mkdir -p /tmp/credit_card_data && cp /data/DataFixABD.csv /tmp/credit_card_data/"
docker-compose exec -T namenode hdfs dfs -mkdir -p /data/credit_card
docker-compose exec -T namenode hdfs dfs -put /tmp/credit_card_data/DataFixABD.csv /data/credit_card/

# Step 3: Create Hive table
Write-Host "Step 3: Membuat tabel Hive..." -ForegroundColor Green

# Create Hive table script
$hiveScript = @"
USE default;

CREATE EXTERNAL TABLE IF NOT EXISTS credit_card_data (
    id INT,
    nama_pelanggan STRING,
    tipe_kartu STRING,
    limit_kartu DOUBLE,
    tagihan DOUBLE,
    pembayaran DOUBLE,
    skor_kredit INT,
    usia INT,
    pendidikan STRING,
    status_pernikahan STRING,
    jumlah_tanggungan INT
) 
ROW FORMAT DELIMITED 
FIELDS TERMINATED BY ',' 
STORED AS TEXTFILE 
LOCATION '/data/credit_card/'
TBLPROPERTIES ('skip.header.line.count'='1');
"@

# Save to file
$hiveScript | Out-File -FilePath "./superset/init/create_hive_table.hql" -Encoding UTF8 -Force

# Run the Hive script
Write-Host "  Menjalankan script Hive..." -ForegroundColor Gray
docker-compose exec -T spark-master /opt/spark/bin/beeline -u jdbc:hive2://spark-master:10000 -f /app/superset_init/create_hive_table.hql

# Step 4: Create credential for Hive-Superset connection
Write-Host "Step 4: Menambahkan koneksi Hive di Superset..." -ForegroundColor Green

$pythonCreateConnection = @"
import os
import sys

try:
    from superset import app, security_manager
    from superset.models.core import Database
    from sqlalchemy.engine.url import make_url

    with app.app_context():
        db = Database(
            database_name='Credit Card DB',
            sqlalchemy_uri='hive://hive@spark-master:10000/default',
            expose_in_sqllab=True
        )
        db.set_sqlalchemy_url('hive://hive@spark-master:10000/default')
        
        # Check if database with same name exists
        existing = db.get_sqla_engine().execute("SHOW DATABASES").fetchall()
        print(f"Available databases: {existing}")
        
        # Create if not exists
        if not security_manager.get_session.query(Database).filter_by(database_name='Credit Card DB').first():
            security_manager.get_session.add(db)
            security_manager.get_session.commit()
            print("Database connection created successfully!")
        else:
            print("Database connection already exists!")

except Exception as e:
    print(f"Error creating connection: {e}")
    sys.exit(1)
"@

# Save to file
$pythonCreateConnection | Out-File -FilePath "./superset/init/create_connection.py" -Encoding UTF8 -Force

# Run the Python script in Superset
Write-Host "  Menambahkan koneksi database di Superset..." -ForegroundColor Gray
docker-compose exec -T superset python /app/superset_init/create_connection.py

Write-Host "`nIntegrasi data dengan Superset telah dilakukan!" -ForegroundColor Cyan
Write-Host "Anda dapat mengakses Superset di http://localhost:8088 atau http://127.0.0.1:8088" -ForegroundColor White
Write-Host "Gunakan kredensial: admin / admin" -ForegroundColor White
