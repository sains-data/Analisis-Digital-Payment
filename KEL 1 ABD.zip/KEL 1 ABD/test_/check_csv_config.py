from superset.app import create_app
app = create_app()
with app.app_context():
    csv_enabled = app.config.get('FEATURE_FLAGS', {}).get('ALLOW_CSV_UPLOAD', False)
    file_upload = app.config.get('ALLOW_FILE_UPLOAD', False)
    print(f"CSV Upload enabled: {csv_enabled}")
    print(f"File Upload allowed: {file_upload}")
