# QUICK FIX SUPERSET LOGIN

## Langkah Cepat

1. Buka PowerShell sebagai Administrator
2. Jalankan script standalone:

```
cd C:\Users\Fadhil\Downloads\test_\test_
.\fix-superset-standalone.ps1
```

3. Tunggu proses selesai (sekitar 1-2 menit)
4. Buka browser dan akses:
   - http://127.0.0.1:8088
   
5. Login dengan kredensial:
   - Username: admin
   - Password: admin

## Jika Masih Bermasalah

1. Restart Docker Desktop
2. Jalankan kembali script
3. Coba dengan mode Incognito/Private pada browser

## Bantuan Lanjutan

Lihat dokumentasi lengkap di file PANDUAN_PERBAIKAN_LOGIN.md
