# PANDUAN PERBAIKAN LOGIN SUPERSET

## Masalah yang Diketahui

1. **"localhost refused to connect"** - Browser tidak dapat terhubung ke Superset di port 8088
2. **"invalid login"** - Kredensial admin tidak diterima oleh Superset
3. **"custom-superset image not found"** - Image Docker kustom tidak tersedia

## Solusi Cepat

### Metode 1: Menggunakan Image Resmi (DIREKOMENDASIKAN)

Solusi tercepat adalah menggunakan image resmi Apache Superset:

```powershell
# Untuk Windows
.\run-superset-official.ps1
```

Script ini:
1. Menggunakan image resmi `apache/superset:latest`
2. Menghindari masalah build image kustom
3. Mengkonfigurasi Superset dengan benar untuk login
4. Menambahkan dependensi yang dibutuhkan

### Metode 2: Menggunakan Script Standalone

Script standalone yang sudah ada juga mengatasi berbagai masalah:

```powershell
# Untuk Windows
.\fix-superset-login-specific.ps1

# Untuk Linux/Mac
./fix-superset-login.sh
```

Script ini akan:
1. Menghentikan dan menghapus container Superset yang ada
2. Menghapus volume yang mungkin rusak
3. Membangun image baru dengan dependensi yang benar
4. Menjalankan container dengan konfigurasi yang benar
5. Membuat user admin baru

### Metode 3: Menggunakan Script Diagnostik

Untuk diagnosa lebih lanjut:
```powershell
.\enhanced-diagnosis.ps1
```

Script ini akan membantu mengidentifikasi masalah spesifik dengan:
- Status container
- Log error
- Masalah jaringan
- Masalah konfigurasi

### Metode 4: Perbaikan Manual

#### Alternatif 1: Menggunakan Image Resmi Apache Superset

1. Berhenti dan hapus container:
   ```powershell
   docker-compose -f docker-compose-superset.yml down
   docker rm -f superset 2>$null
   ```

2. Buat file docker-compose-superset-official.yml dengan konten berikut:
   ```yaml
   version: '3.7'
   
   services:
     superset:
       image: apache/superset:latest
       container_name: superset
       restart: always
       ports:
         - "8088:8088"
       environment:
         - SUPERSET_SECRET_KEY=your_secret_key_here
         - SUPERSET_LOAD_EXAMPLES=false
         - PYTHONPATH=/app/pythonpath:/app/superset_init
         - WTF_CSRF_ENABLED=false
         - FLASK_ENV=development
         - SUPERSET_WEBSERVER_ADDRESS=0.0.0.0
       volumes:
         - ./superset/superset_config.py:/app/pythonpath/superset_config.py
         - ./superset/init:/app/superset_init
         - superset_home:/app/superset_home
       command: >
         bash -c "
           superset db upgrade &&
           superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force &&
           superset init &&
           gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 'superset.app:create_app()'
         "
       networks:
         - hadoop
   
   volumes:
     superset_home:
   
   networks:
     hadoop:
       external: true
   ```

3. Jalankan container:
   ```powershell
   docker-compose -f docker-compose-superset-official.yml up -d
   ```

4. Instalasi tambahan dependensi:
   ```powershell
   docker-compose -f docker-compose-superset-official.yml exec superset pip install pyhive[hive]==0.7.0 sasl==0.3.1 thrift==0.16.0 thrift_sasl==0.4.3 werkzeug==2.0.3
   ```

#### Alternatif 2: Menggunakan Custom Image

1. Berhenti dan hapus container:
   ```powershell
   docker-compose stop superset superset-init
   docker-compose rm -f superset superset-init
   docker volume rm -f test__superset_home
   ```

2. Bangun image dengan dependensi (pastikan Dockerfile.superset memiliki pkg-config):
   ```powershell
   docker build -t custom-superset:fixed -f Dockerfile.superset .
   ```

3. Jalankan container baru:
   ```powershell
   docker-compose -f docker-compose-superset.yml up -d
   ```

4. Buat admin baru:
   ```powershell
   docker-compose exec superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force
   docker-compose exec superset superset init
   ```

## Tips Tambahan

1. **Gunakan IP daripada hostname**: 
   - Coba akses http://127.0.0.1:8088 alih-alih http://localhost:8088

2. **Periksa Port 8088**: 
   - Pastikan tidak ada aplikasi lain yang menggunakan port 8088
   - Jika port 8088 digunakan aplikasi lain, ubah port di docker-compose.yml ke port lain (mis. 8099)

3. **Cek File Hosts**:
   - Pastikan ada entri "127.0.0.1 localhost" di file hosts

4. **Periksa Docker Network**:
   - Pastikan container Superset berada di jaringan yang benar

5. **Reset Browser Cache**:
   - Bersihkan cache dan cookie browser, atau coba browser lain

## Setelah Berhasil Login

Setelah berhasil login, konfigurasi koneksi ke database Hive:

1. Buka Data > Databases > + Database
2. Pilih Apache Hive
3. Masukkan:
   - Display Name: Credit Card DB
   - SQL Alchemy URI: hive://hive@spark-master:10000/default
4. Klik Test Connection
5. Klik Save
