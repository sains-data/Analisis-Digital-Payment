# Script sederhana untuk menjalankan Superset dengan image resmi
Write-Host "=== MENJALANKAN APACHE SUPERSET DENGAN IMAGE RESMI (VERSI SIMPLE) ===" -ForegroundColor Cyan

# Berhenti dan hapus container Superset yang sudah ada
Write-Host "Step 1: Membersihkan container Superset..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml down
docker rm -f superset 2>$null

# Buat file konfigurasi docker-compose untuk Superset resmi
Write-Host "Step 2: Membuat file konfigurasi Superset resmi..." -ForegroundColor Green
$content = @"
version: '3'

services:
  superset:
    image: apache/superset:latest
    container_name: superset
    restart: always
    ports:
      - "8088:8088"
    environment:
      - SUPERSET_SECRET_KEY=your_secret_key_here
      - SUPERSET_LOAD_EXAMPLES=false
      - PYTHONPATH=/app/pythonpath:/app/superset_init
      - WTF_CSRF_ENABLED=false
      - SUPERSET_WEBSERVER_ADDRESS=0.0.0.0
    volumes:
      - ./superset/superset_config.py:/app/pythonpath/superset_config.py
      - ./superset/init:/app/superset_init
      - superset_home:/app/superset_home
    command: >
      bash -c "
        superset db upgrade &&
        superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force &&
        superset init &&
        gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 'superset.app:create_app()'
      "
    networks:
      - hadoop

volumes:
  superset_home:

networks:
  hadoop:
    external: true
"@

$content | Out-File -FilePath "./docker-compose-superset-simple.yml" -Encoding UTF8

# Jalankan container Superset dengan image resmi
Write-Host "Step 3: Menjalankan Superset dengan image resmi..." -ForegroundColor Green
docker-compose -f docker-compose-superset-simple.yml up -d

# Tunggu sebentar untuk memberi waktu container Superset untuk berjalan
Write-Host "Step 4: Menunggu Superset siap (20 detik)..." -ForegroundColor Green
Start-Sleep -Seconds 20

# Instalasi dependensi untuk koneksi database
Write-Host "Step 5: Menginstal dependensi untuk koneksi database..." -ForegroundColor Green
docker exec -it superset pip install pyhive[hive]==0.7.0 sasl==0.3.1 thrift==0.16.0 thrift_sasl==0.4.3

# Cek status container
Write-Host "Step 6: Memeriksa status container Superset..." -ForegroundColor Green
docker ps -a | Select-String "superset"

Write-Host "`nSuperset seharusnya sudah berjalan!" -ForegroundColor Cyan
Write-Host "Akses Superset di: http://localhost:8088 atau http://127.0.0.1:8088" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
Write-Host "`nJika masih tidak bisa diakses, coba tunggu 30-60 detik lagi atau gunakan mode incognito browser" -ForegroundColor Yellow
