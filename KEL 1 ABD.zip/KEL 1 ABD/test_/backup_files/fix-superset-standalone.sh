#!/bin/bash
# Script untuk menjalankan Superset dan memperbaiki masalah login
# Simpan sebagai fix-superset-standalone.sh

echo "=== SUPERSET STANDALONE FIX ==="
echo ""

# 1. Bersihkan container Superset lama jika ada
echo "1. Bersihkan container Superset lama..."
docker stop superset 2>/dev/null
docker rm superset 2>/dev/null

# 2. Hapus volume yang mungkin rusak
echo "2. Hapus volume Superset..."
docker volume rm -f test__superset_home 2>/dev/null

# 3. Build image Superset dengan dependensi yang benar
echo "3. Build custom Superset image..."
docker build -t custom-superset:fixed -f Dockerfile.superset .

# 4. Jalankan container Superset dengan port dan konfigurasi yang benar
echo "4. Menjalankan container Superset..."
docker run -d --name superset \
  -p 8088:8088 \
  -v ./superset/superset_config.py:/app/pythonpath/superset_config.py \
  -v ./superset/init:/app/superset_init \
  -e SUPERSET_SECRET_KEY=your_secret_key_here \
  -e SUPERSET_LOAD_EXAMPLES=false \
  -e PYTHONPATH=/app/pythonpath:/app/superset_init \
  custom-superset:fixed

# 5. Tunggu beberapa saat agar container siap
echo "5. Menunggu container siap (30 detik)..."
sleep 30

# 6. Inisialisasi dan setup admin
echo "6. Setup database dan user admin..."
docker exec -it superset bash -c "
superset db upgrade &&
superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force &&
superset init
"

# 7. Informasi koneksi
echo ""
echo "=== SUPERSET READY ==="
echo "URL: http://localhost:8088"
echo "Username: admin"
echo "Password: admin"
echo ""
echo "Jika masih ada masalah, coba akses dengan IP 127.0.0.1:8088 sebagai alternatif localhost."
