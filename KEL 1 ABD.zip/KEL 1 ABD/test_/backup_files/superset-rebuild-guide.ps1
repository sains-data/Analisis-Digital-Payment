# Script to rebuild and fix Superset container
# This must be executed as individual commands

Write-Host "===== SUPERSET REBUILD STEP-BY-STEP GUIDE =====" -ForegroundColor Cyan
Write-Host ""
Write-Host "Run these commands in sequence to fix the Superset container:" -ForegroundColor Yellow
Write-Host ""

Write-Host "STEP 1: Stop existing containers" -ForegroundColor Green
Write-Host "docker-compose stop superset superset-init" -ForegroundColor White
Write-Host ""

Write-Host "STEP 2: Remove containers" -ForegroundColor Green
Write-Host "docker-compose rm -f superset superset-init" -ForegroundColor White
Write-Host ""

Write-Host "STEP 3: Remove volume" -ForegroundColor Green
Write-Host "docker volume rm test__superset_home" -ForegroundColor White
Write-Host ""

Write-Host "STEP 4: Create Dockerfile" -ForegroundColor Green
Write-Host "Create a file named 'Dockerfile.superset' with the following content:" -ForegroundColor Yellow
Write-Host @"
FROM apache/superset:latest

# Install build tools dan dependensi
USER root
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
    build-essential \
    gcc \
    g++ \
    libsasl2-dev

# Install Python packages dengan dependensi yang dibutuhkan
RUN pip install flask-cors==3.0.10 \
    psycopg2-binary \
    pyathena \
    sqlalchemy==1.4.46 \
    sasl \
    thrift_sasl \
    pyhive[hive]

USER superset
"@ -ForegroundColor Gray
Write-Host ""

Write-Host "STEP 5: Build custom image" -ForegroundColor Green
Write-Host "docker build -t custom-superset:latest -f Dockerfile.superset ." -ForegroundColor White
Write-Host ""

Write-Host "STEP 6: Update docker-compose.yml" -ForegroundColor Green
Write-Host "Edit docker-compose.yml and replace:" -ForegroundColor Yellow
Write-Host "  image: apache/superset:latest" -ForegroundColor Gray
Write-Host "with:" -ForegroundColor Yellow
Write-Host "  image: custom-superset:latest" -ForegroundColor Gray
Write-Host ""

Write-Host "STEP 7: Start container" -ForegroundColor Green
Write-Host "docker-compose up -d superset" -ForegroundColor White
Write-Host ""

Write-Host "STEP 8: Initialize Superset" -ForegroundColor Green
Write-Host "Give the container about 30 seconds to start, then run:" -ForegroundColor Yellow
Write-Host "docker-compose exec superset superset db upgrade" -ForegroundColor White
Write-Host "docker-compose exec superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin" -ForegroundColor White
Write-Host "docker-compose exec superset superset init" -ForegroundColor White
Write-Host ""

Write-Host "STEP 9: Access Superset" -ForegroundColor Green
Write-Host "Open http://localhost:8088 in your browser" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White  
Write-Host "Password: admin" -ForegroundColor White
