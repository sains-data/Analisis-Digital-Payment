#!/bin/bash
# Script untuk memperbaiki masalah SASL di Superset

echo "=== FIXING SUPERSET SASL ISSUE ==="

# 1. Stop dan hapus container yang ada
echo "Stopping and removing existing containers..."
docker-compose stop superset superset-init
docker-compose rm -f superset superset-init

# 2. Hapus volume jika ada
echo "Removing existing volumes..."
docker volume rm test__superset_home 2>/dev/null || true

# 3. Buat container baru dengan Dockerfile khusus
echo "Creating temporary Dockerfile for Superset..."
cat > Dockerfile.superset << EOF
FROM apache/superset:latest

# Install build tools dan dependensi
USER root
RUN apt-get update && \\
    apt-get install -y --no-install-recommends \\
    build-essential \\
    gcc \\
    g++ \\
    libsasl2-dev

# Install Python packages dengan dependensi yang dibutuhkan
RUN pip install flask-cors==3.0.10 \\
    psycopg2-binary \\
    pyathena \\
    sqlalchemy==1.4.46 \\
    sasl \\
    thrift_sasl \\
    pyhive[hive]

USER superset
EOF

# 4. Build image baru
echo "Building custom Superset image..."
docker build -t custom-superset:latest -f Dockerfile.superset .

# 5. Update Docker Compose configuration
echo "Updating docker-compose.yml..."
sed -i 's|image: apache/superset:latest|image: custom-superset:latest|g' docker-compose.yml

# 6. Start container
echo "Starting Superset container..."
docker-compose up -d superset

echo "=== DONE ==="
echo "Wait for 30-60 seconds for container to initialize"
echo "Then access Superset at http://localhost:8088"
echo "Username: admin"
echo "Password: admin"
