# Script untuk memperbaiki masalah SASL di Superset

Write-Host "=== FIXING SUPERSET SASL ISSUE ===" -ForegroundColor Cyan

# 1. Stop dan hapus container yang ada
Write-Host "Menghentikan dan menghapus container yang ada..." -ForegroundColor Yellow
docker-compose stop superset superset-init
docker-compose rm -f superset superset-init

# 2. Hapus volume jika ada
Write-Host "Menghapus volume yang ada..." -ForegroundColor Yellow
docker volume rm test__superset_home 2>$null

# 3. Buat container baru dengan Dockerfile khusus
Write-Host "Membuat Dockerfile sementara untuk Superset..." -ForegroundColor Yellow
@"
FROM apache/superset:latest

# Install build tools dan dependensi
USER root
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
    build-essential \
    gcc \
    g++ \
    libsasl2-dev

# Install Python packages dengan dependensi yang dibutuhkan
RUN pip install flask-cors==3.0.10 \
    psycopg2-binary \
    pyathena \
    sqlalchemy==1.4.46 \
    sasl \
    thrift_sasl \
    pyhive[hive]

USER superset
"@ | Out-File -FilePath "Dockerfile.superset" -Encoding utf8

# 4. Build image baru
Write-Host "Building custom Superset image..." -ForegroundColor Yellow
docker build -t custom-superset:latest -f Dockerfile.superset .

# 5. Update Docker Compose configuration untuk menggunakan image baru
Write-Host "Updating docker-compose.yml..." -ForegroundColor Yellow
(Get-Content -Path "docker-compose.yml") -replace "image: apache/superset:latest", "image: custom-superset:latest" | Set-Content -Path "docker-compose.yml"

# 6. Jalankan container
Write-Host "Menjalankan container Superset..." -ForegroundColor Yellow
docker-compose up -d superset

Write-Host "=== SELESAI ===" -ForegroundColor Green
Write-Host "Tunggu 30-60 detik agar container selesai diinisialisasi" -ForegroundColor Yellow
Write-Host "Kemudian akses Superset di http://localhost:8088" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
