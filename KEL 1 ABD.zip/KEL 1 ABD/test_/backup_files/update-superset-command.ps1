# Script untuk memperbarui command di docker-compose.yml

# Baca file docker-compose.yml
$content = Get-Content -Path "docker-compose.yml" -Raw

# Perbarui bagian command untuk superset
$pattern = '(?s)(superset:.*?command: >.*?)bash -c "pip install flask-cors.*?superset\.app:create_app\(\)"\)"(.*?networks:)'
$replacement = '${1}bash -c "apt-get update && apt-get install -y --no-install-recommends build-essential gcc g++ libsasl2-dev && pip install flask-cors==3.0.10 psycopg2-binary pyathena sqlalchemy==1.4.46 sasl thrift_sasl && pip install pyhive[hive] && gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 '\''superset.app:create_app()'\''"'
$newContent = $content -replace $pattern, "$replacement`$2networks:"

# Simpan kembali file
$newContent | Set-Content -Path "docker-compose.yml" -Force

Write-Host "Docker compose file berhasil diperbarui" -ForegroundColor Green
