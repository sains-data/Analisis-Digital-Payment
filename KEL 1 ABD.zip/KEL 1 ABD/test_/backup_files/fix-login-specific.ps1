# Perbaikan spesifik untuk masalah login di Superset

Write-Host "=== PERBAIKAN SPESIFIK LOGIN SUPERSET ===" -ForegroundColor Cyan
Write-Host "Script ini akan memperbaiki hanya bagian yang bermasalah saja" -ForegroundColor Yellow

# 1. Tambahkan entri ke host file
Write-Host "1. Memastikan entri localhost ada di file hosts..." -ForegroundColor Gray
try {
    $hostsPath = "$env:windir\System32\drivers\etc\hosts"
    $hostsContent = Get-Content -Path $hostsPath -Raw
    if ($hostsContent -notmatch "127.0.0.1\s+localhost") {
        Write-Host "   Menambahkan localhost ke file hosts..." -ForegroundColor Yellow
        Add-Content -Path $hostsPath -Value "`n127.0.0.1 localhost" -Force -ErrorAction SilentlyContinue
        Write-Host "   Selesai." -ForegroundColor Green
    } else {
        Write-Host "   Entri localhost sudah ada." -ForegroundColor Green
    }
} catch {
    Write-Host "   Tidak dapat memodifikasi file hosts. Coba jalankan sebagai Administrator." -ForegroundColor Red
}

# 2. Matikan CSRF di superset_config.py
Write-Host "`n2. Menonaktifkan CSRF untuk memperbaiki masalah login..." -ForegroundColor Gray
try {
    $configPath = ".\superset\superset_config.py"
    $configContent = Get-Content -Path $configPath -Raw -ErrorAction SilentlyContinue
    
    if ($configContent) {
        if ($configContent -notmatch "WTF_CSRF_ENABLED = False") {
            $newConfig = $configContent -replace "WTF_CSRF_ENABLED = True", "WTF_CSRF_ENABLED = False"
            if ($newConfig -eq $configContent) {
                # Jika tidak ada yang diganti, tambahkan saja
                $newConfig += "`n# Disable CSRF untuk memperbaiki masalah login`nWTF_CSRF_ENABLED = False`n"
            }
            Set-Content -Path $configPath -Value $newConfig -Force
            Write-Host "   Konfigurasi CSRF berhasil diubah." -ForegroundColor Green
        } else {
            Write-Host "   CSRF sudah dinonaktifkan." -ForegroundColor Green
        }
    } else {
        Write-Host "   File konfigurasi superset_config.py tidak ditemukan." -ForegroundColor Red
    }
} catch {
    Write-Host "   Gagal memodifikasi file konfigurasi: $($_.Exception.Message)" -ForegroundColor Red
}

# 3. Fix database yang rusak dengan menginisialisasi ulang
Write-Host "`n3. Memperbaiki database Superset..." -ForegroundColor Gray
$fixDatabaseScript = @"
#!/bin/bash
echo "Fixing Superset database issues..."

# Reset permissions
chmod -R 777 /app/superset_home

# Upgrade database
superset db upgrade

# Create admin user
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

# Initialize
superset init

echo "Database fix complete!"
"@

try {
    # Simpan script fix
    New-Item -Path ".\superset\init" -ItemType Directory -Force -ErrorAction SilentlyContinue | Out-Null
    Set-Content -Path ".\superset\init\fix_database.sh" -Value $fixDatabaseScript -Force
    Write-Host "   Script perbaikan database berhasil dibuat." -ForegroundColor Green
    
    # Jalankan script fix
    docker-compose exec -T superset bash -c "chmod +x /app/superset_init/fix_database.sh && /app/superset_init/fix_database.sh"
    Write-Host "   Perbaikan database selesai." -ForegroundColor Green
} catch {
    Write-Host "   Gagal memperbaiki database: $($_.Exception.Message)" -ForegroundColor Red
}

# 4. Restart container untuk menerapkan perubahan
Write-Host "`n4. Restart container Superset..." -ForegroundColor Gray
try {
    docker-compose restart superset
    Write-Host "   Container Superset berhasil di-restart." -ForegroundColor Green
} catch {
    Write-Host "   Gagal me-restart container: $($_.Exception.Message)" -ForegroundColor Red
}

# 5. Periksa apakah port 8088 digunakan oleh aplikasi lain
Write-Host "`n5. Memeriksa konflik port 8088..." -ForegroundColor Gray
try {
    $portCheck = netstat -ano | findstr ":8088"
    if ($portCheck) {
        $dockerPort = docker port $(docker-compose ps -q superset) 2>$null
        
        if (($portCheck -match "0.0.0.0:8088") -and ($dockerPort -match "8088")) {
            Write-Host "   Port 8088 digunakan oleh container Superset, ini normal." -ForegroundColor Green
        } else {
            Write-Host "   PERINGATAN: Port 8088 mungkin digunakan oleh aplikasi lain!" -ForegroundColor Red
            Write-Host "   $portCheck" -ForegroundColor Yellow
            Write-Host "   Ini dapat menyebabkan konflik dan menjadi penyebab masalah login." -ForegroundColor Red
        }
    } else {
        Write-Host "   Port 8088 tidak terdeteksi digunakan. Container mungkin tidak berjalan." -ForegroundColor Yellow
    }
} catch {
    Write-Host "   Gagal memeriksa port: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== INSTRUKSI UNTUK LOGIN ===" -ForegroundColor Cyan
Write-Host "1. Tunggu 10-15 detik untuk memastikan container sudah siap" -ForegroundColor White
Write-Host "2. PENTING: Gunakan alamat IP, bukan hostname:" -ForegroundColor Yellow
Write-Host "   http://127.0.0.1:8088" -ForegroundColor White
Write-Host "3. Bersihkan cache browser atau gunakan mode incognito/private" -ForegroundColor White 
Write-Host "4. Login dengan kredensial:" -ForegroundColor White
Write-Host "   Username: admin" -ForegroundColor White
Write-Host "   Password: admin" -ForegroundColor White
Write-Host "`nJika masih gagal, coba gunakan browser lain seperti Firefox atau Edge" -ForegroundColor Yellow
