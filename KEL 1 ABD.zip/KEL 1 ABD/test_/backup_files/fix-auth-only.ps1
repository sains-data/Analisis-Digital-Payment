# Fix khusus untuk masalah autentikasi Superset

Write-Host "=== PERBAIKAN KHUSUS AUTENTIKASI SUPERSET ===" -ForegroundColor Cyan

# 1. Periksa status container
$containerStatus = docker-compose ps superset
if ($containerStatus -notmatch "Up") {
    Write-Host "Container Superset tidak berjalan. Menjalankan container..." -ForegroundColor Yellow
    docker-compose up -d superset
    Start-Sleep -Seconds 20
}

# 2. Ubah konfigurasi autentikasi langsung di container
$authFixScript = @"
#!/bin/bash
echo "Memperbaiki konfigurasi autentikasi..."

# Ubah konfigurasi Flask-AppBuilder secara langsung
python3 << EOF
import os
from flask_appbuilder.security.manager import AUTH_DB

# Lokasi file konfigurasi
config_file = '/app/pythonpath/superset_config.py'

# Baca file konfigurasi yang ada
if os.path.exists(config_file):
    with open(config_file, 'r') as f:
        config = f.read()
    
    # Tambahkan pengaturan autentikasi
    auth_settings = '''
# Pengaturan autentikasi tambahan untuk memperbaiki masalah login
AUTH_TYPE = 1  # AUTH_DB
WTF_CSRF_ENABLED = False
CSRF_ENABLED = False
AUTH_PASSWORD_LOGIN = True
PUBLIC_ROLE_LIKE_GAMMA = True
FAB_API_SWAGGER_UI = True
ENABLE_PROXY_FIX = True
'''
    
    # Cek apakah sudah ada konfigurasi diatas
    if 'AUTH_PASSWORD_LOGIN = True' not in config:
        with open(config_file, 'a') as f:
            f.write(auth_settings)
        print("Konfigurasi autentikasi berhasil ditambahkan")
    else:
        print("Konfigurasi autentikasi sudah ada")
else:
    print("File konfigurasi tidak ditemukan")

# Reset Flask-AppBuilder session
if os.path.exists('/app/superset_home/superset.db'):
    print("Menghapus tabel session...")
    import sqlite3
    conn = sqlite3.connect('/app/superset_home/superset.db')
    try:
        conn.execute('DELETE FROM ab_user WHERE username != "admin"')
        conn.execute('DELETE FROM ab_user_role WHERE user_id != 1')
        conn.execute('DELETE FROM ab_permission_view_role WHERE role_id != 1')
        conn.commit()
        print("Tabel session berhasil dibersihkan")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        conn.close()
EOF

# Reinisialisasi admin user
echo "Membuat ulang admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

# Reset permissions
echo "Mengatur ulang permissions..."
superset init

echo "Perbaikan autentikasi selesai"
"@

# Simpan script di container dan jalankan
Write-Host "Menerapkan perbaikan autentikasi..." -ForegroundColor Yellow
$authFixScript | docker exec -i superset bash -c "cat > /tmp/auth_fix.sh && chmod +x /tmp/auth_fix.sh && /tmp/auth_fix.sh"

# Restart container untuk menerapkan perubahan
Write-Host "Me-restart container Superset..." -ForegroundColor Yellow
docker-compose restart superset
Write-Host "Menunggu container siap (10 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 10

Write-Host "`nPerbaikan autentikasi selesai!" -ForegroundColor Green
Write-Host "`nPENTING: Gunakan URL ini untuk login:" -ForegroundColor Magenta
Write-Host "http://127.0.0.1:8088" -ForegroundColor White
Write-Host "`nKredensial:" -ForegroundColor Yellow
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
