# Script to rebuild the Superset container with proper dependencies

Write-Host "=== REBUILDING SUPERSET CONTAINER ===" -ForegroundColor Cyan
Write-Host "Stopping all related containers..." -ForegroundColor Yellow
docker-compose stop superset superset-init

Write-Host "Removing containers..." -ForegroundColor Yellow
docker-compose rm -f superset superset-init

Write-Host "Removing volume..." -ForegroundColor Yellow
docker volume rm test__superset_home

Write-Host "Rebuilding containers..." -ForegroundColor Yellow
docker-compose up -d superset

Write-Host "Waiting for container to initialize (30 seconds)..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

Write-Host "Installing required dependencies..." -ForegroundColor Yellow
docker-compose exec -T superset bash -c "pip install flask-cors==3.0.10 psycopg2-binary pyathena pyhive[hive] sqlalchemy==1.4.46"

Write-Host "Initializing Superset..." -ForegroundColor Yellow
docker-compose exec -T superset bash -c "superset db upgrade && superset init"

Write-Host "Creating admin user..." -ForegroundColor Yellow
docker-compose exec -T superset bash -c "superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin"

Write-Host "Restarting Superset..." -ForegroundColor Yellow
docker-compose restart superset

Write-Host "Done! Try accessing Superset at http://localhost:8088" -ForegroundColor Green
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White

# Add a direct test section
Write-Host "`n=== TESTING CONNECTION ===" -ForegroundColor Cyan
Write-Host "1. Checking if port 8088 is open..." -ForegroundColor Yellow
$portCheck = Test-NetConnection localhost -Port 8088 -ErrorAction SilentlyContinue
if ($portCheck.TcpTestSucceeded) {
    Write-Host "Port 8088 is open!" -ForegroundColor Green
} else {
    Write-Host "Port 8088 is NOT open." -ForegroundColor Red
}

Write-Host "`n2. Trying HTTP request..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8088" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
    Write-Host "Connection successful! Status: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "Connection failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n3. Also try in your browser:" -ForegroundColor Yellow
Write-Host "   http://localhost:8088" -ForegroundColor White
Write-Host "   http://127.0.0.1:8088" -ForegroundColor White
