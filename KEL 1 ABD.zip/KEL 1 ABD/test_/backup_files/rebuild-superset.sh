#!/bin/bash
# Script to rebuild the Superset container with proper dependencies

echo "=== REBUILDING SUPERSET CONTAINER ==="
echo "Stopping all related containers..."
docker-compose stop superset superset-init

echo "Removing containers..."
docker-compose rm -f superset superset-init

echo "Removing volume..."
docker volume rm test__superset_home

echo "Rebuilding containers..."
docker-compose up -d superset

echo "Waiting for container to initialize (30 seconds)..."
sleep 30

echo "Installing required dependencies..."
docker-compose exec -T superset bash -c "pip install flask-cors==3.0.10 psycopg2-binary pyathena pyhive[hive] sqlalchemy==1.4.46"

echo "Initializing Superset..."
docker-compose exec -T superset bash -c "superset db upgrade && superset init"

echo "Creating admin user..."
docker-compose exec -T superset bash -c "superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin"

echo "Restarting Superset..."
docker-compose restart superset

echo "Done! Try accessing Superset at http://localhost:8088"
echo "Username: admin"
echo "Password: admin"
