# Script to reset Superset container and recreate it

Write-Host "Resetting Superset container..." -ForegroundColor Red

# Stop and remove Superset containers
Write-Host "Stopping and removing Superset containers..." -ForegroundColor Yellow
docker-compose stop superset superset-init
docker-compose rm -f superset superset-init

# Start Superset containers again
Write-Host "Starting Superset containers fresh..." -ForegroundColor Green
docker-compose up -d superset superset-init

# Wait for services to be ready
Write-Host "Waiting for services to initialize..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

Write-Host "Superset has been reset. Try logging in with:" -ForegroundColor Green
Write-Host "URL: http://localhost:8088" -ForegroundColor White
Write-Host "Username: admin" -ForegroundColor White
Write-Host "Password: admin" -ForegroundColor White
