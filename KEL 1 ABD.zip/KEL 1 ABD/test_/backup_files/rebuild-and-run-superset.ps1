# Script untuk membangun ulang dan menjalankan Superset dengan bersih

Write-Host "=== SUPERSET REBUILD AND RUN TOOLKIT ===" -ForegroundColor Cyan
Write-Host ""

# Step 1: Stop and remove existing Superset containers
Write-Host "Step 1: Stopping and removing existing Superset containers..." -ForegroundColor Yellow
docker-compose stop superset superset-init
docker-compose rm -f superset superset-init
docker volume rm -f test__superset_home

# Step 2: Rebuild the custom Superset image
Write-Host "Step 2: Building custom Superset image..." -ForegroundColor Yellow
docker build -t custom-superset:fixed -f Dockerfile.superset .

# Step 3: Create any missing directories
Write-Host "Step 3: Creating required directories..." -ForegroundColor Yellow
if (-not (Test-Path -Path ".\superset\init")) {
    New-Item -ItemType Directory -Path ".\superset\init" -Force
    Write-Host "  Created .\superset\init directory" -ForegroundColor Gray
}

# Step 4: Create initialization script
Write-Host "Step 4: Creating initialization script..." -ForegroundColor Yellow
$initScript = @"
#!/bin/bash
echo "Initializing Superset..."
pip install flask-cors==3.0.10
pip install psycopg2-binary
pip install pyathena
pip install sqlalchemy==1.4.46
pip install sasl thrift_sasl
pip install pyhive[hive]

echo "Running DB upgrade..."
superset db upgrade

echo "Creating admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

echo "Initializing Superset..."
superset init

echo "Setting permissions..."
chmod -R 777 /app/superset_home

echo "Initialization complete!"
"@

$initScript | Out-File -FilePath ".\superset\init\init_superset.sh" -Encoding UTF8 -Force

# Step 5: Start the containers in specific order
Write-Host "Step 5: Starting containers..." -ForegroundColor Yellow
docker-compose up -d superset-init
Write-Host "  Waiting for superset-init to complete (30 seconds)..." -ForegroundColor Gray
Start-Sleep -Seconds 30
docker-compose up -d superset

# Step 6: Wait for Superset to be ready
Write-Host "Step 6: Waiting for Superset to be ready..." -ForegroundColor Yellow
$attempts = 0
$maxAttempts = 10
$isReady = $false

while (-not $isReady -and $attempts -lt $maxAttempts) {
    $attempts++
    Write-Host "  Attempt $attempts of $maxAttempts..." -ForegroundColor Gray
    try {
        $response = Invoke-RestMethod -Uri "http://localhost:8088/api/v1/health" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
        if ($response) {
            $isReady = $true
            Write-Host "  Superset is ready!" -ForegroundColor Green
        }
    }
    catch {
        Write-Host "  Superset not ready yet, waiting..." -ForegroundColor Yellow
        Start-Sleep -Seconds 15
    }
}

if (-not $isReady) {
    Write-Host "Superset might not be fully ready. Check logs for more details:" -ForegroundColor Yellow
    docker-compose logs superset --tail 20
}
else {
    # Final verification of admin credentials
    Write-Host "`nVerifying admin credentials..." -ForegroundColor Yellow
    docker-compose exec -T superset superset fab create-admin `
        --username admin `
        --firstname Superset `
        --lastname Admin `
        --email admin@superset.com `
        --password admin `
        --force

    Write-Host "Final initialization..." -ForegroundColor Yellow
    docker-compose exec -T superset superset init
}

Write-Host "`n=== SETUP COMPLETE ===" -ForegroundColor Cyan
Write-Host "You can now access Superset at:" -ForegroundColor White
Write-Host "  URL: http://localhost:8088" -ForegroundColor White
Write-Host "  Username: admin" -ForegroundColor White
Write-Host "  Password: admin" -ForegroundColor White
Write-Host "" 
Write-Host "If you still have issues, try:" -ForegroundColor Yellow
Write-Host "1. Access using 127.0.0.1:8088 instead of localhost" -ForegroundColor White
Write-Host "2. Check container logs: docker-compose logs superset" -ForegroundColor White
Write-Host "3. Ensure no other service is using port 8088" -ForegroundColor White
Write-Host "4. Try restarting Docker Desktop" -ForegroundColor White
