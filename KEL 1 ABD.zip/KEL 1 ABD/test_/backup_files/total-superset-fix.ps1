# Total fix for Superset login issues - more aggressive approach

Write-Host "=== TOTAL SUPERSET LOGIN FIX ===" -ForegroundColor Cyan
Write-Host "This script will completely rebuild Superset container and database" -ForegroundColor Yellow

# 1. Stop all containers
Write-Host "1. Stopping all containers..." -ForegroundColor Gray
docker-compose down

# 2. Removing volumes
Write-Host "2. Removing Superset volumes..." -ForegroundColor Gray
docker volume rm -f test__superset_home

# 3. Updating superset_config.py
Write-Host "3. Updating Superset configuration..." -ForegroundColor Gray

$supersetConfig = @"
import os

# Superset specific config
ROW_LIMIT = 5000
SUPERSET_WEBSERVER_PORT = 8088

# Flask App Builder configuration
# Your App secret key
SECRET_KEY = 'CHANGE_THIS_TO_SOMETHING_COMPLEX'

# Authentication settings
AUTH_TYPE = 1  # Database authentication
AUTH_USER_REGISTRATION = True
AUTH_USER_REGISTRATION_ROLE = "Admin"
AUTH_ROLE_ADMIN = "Admin"
AUTH_ROLE_PUBLIC = "Public"
SQLALCHEMY_TRACK_MODIFICATIONS = False
WTF_CSRF_ENABLED = False  # Disable CSRF for easier login troubleshooting
AUTH_PASSWORD_LOGIN = True

# The SQLAlchemy connection string
SQLALCHEMY_DATABASE_URI = 'sqlite:////app/superset_home/superset.db'

# Disabling CORS
ENABLE_CORS = False

# Caching config
CACHE_CONFIG = {
    'CACHE_TYPE': 'simple',
    'CACHE_DEFAULT_TIMEOUT': 60 * 60 * 24,
}

# Feature flags
FEATURE_FLAGS = {
    'DASHBOARD_NATIVE_FILTERS': True,
    'DASHBOARD_CROSS_FILTERS': True,
    'DASHBOARD_NATIVE_FILTERS_SET': True,
    'DASHBOARD_FILTERS_EXPERIMENTAL': True,
    'EMBEDDED_SUPERSET': True,
}

# Must have for proper connection
SUPERSET_WEBSERVER_ADDRESS = '0.0.0.0'
"@

New-Item -Path "./superset" -ItemType Directory -Force | Out-Null
Set-Content -Path "./superset/superset_config.py" -Value $supersetConfig -Force

# 4. Create a comprehensive init script
Write-Host "4. Creating enhanced initialization script..." -ForegroundColor Gray

$initScript = @"
#!/bin/bash
echo "Beginning comprehensive Superset fix..."

# Install dependencies
echo "Installing dependencies..."
pip install --upgrade pip setuptools wheel
pip install flask-cors==3.0.10
pip install psycopg2-binary
pip install pyathena
pip install sqlalchemy==1.4.46
pip install sasl thrift_sasl
pip install pyhive[hive]
pip install pymysql

# Fix permissions
echo "Setting correct permissions..."
chmod -R 777 /app/superset_home

# Remove any existing database
echo "Removing any existing database..."
rm -f /app/superset_home/superset.db
rm -rf /app/superset_home/.cache
rm -rf /app/superset_home/superset_cache
mkdir -p /app/superset_home/superset_cache

# Initialize database
echo "Initializing database from scratch..."
superset db upgrade

# Create admin user
echo "Creating admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

# Initialize
echo "Initializing Superset..."
superset init

# Load examples (optional)
# superset load_examples

echo "Fix complete. Ready to access Superset!"
"@

New-Item -Path "./superset/init" -ItemType Directory -Force | Out-Null
Set-Content -Path "./superset/init/total_fix.sh" -Value $initScript -Force -Encoding UTF8

# 5. Update Dockerfile
Write-Host "5. Updating Dockerfile..." -ForegroundColor Gray

$dockerfile = @"
FROM apache/superset:latest

USER root

# Install system dependencies
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
    build-essential \
    gcc \
    g++ \
    libsasl2-dev \
    libkrb5-dev \
    libldap2-dev \
    python3-dev \
    default-libmysqlclient-dev \
    curl \
    netcat \
    vim

# Install Python packages
RUN pip install --upgrade pip setuptools wheel && \
    pip install flask-cors==3.0.10 \
    psycopg2-binary \
    pyathena \
    sqlalchemy==1.4.46 \
    sasl \
    thrift_sasl \
    pyhive[hive] \
    python-ldap \
    mysqlclient \
    pymssql && \
    pip cache purge

# Fix permissions
RUN mkdir -p /app/superset_home && \
    chmod -R 777 /app/superset_home

# Set environment variables
ENV SUPERSET_SECRET_KEY="CHANGE_THIS_TO_SOMETHING_COMPLEX"
ENV SUPERSET_LOAD_EXAMPLES=false
ENV PYTHONPATH=/app/pythonpath:/app/superset_init
ENV FLASK_APP="superset.app:create_app()"
ENV SUPERSET_WEBSERVER_ADDRESS="0.0.0.0"
ENV WTF_CSRF_ENABLED=false

COPY ./superset/init /app/superset_init
COPY ./superset/superset_config.py /app/pythonpath/superset_config.py

USER superset
"@

Set-Content -Path "./Dockerfile.superset" -Value $dockerfile -Force

# 6. Update docker-compose file
Write-Host "6. Creating standalone superset docker-compose file..." -ForegroundColor Gray

$dockerCompose = @"
version: '3.7'

services:
  superset:
    build:
      context: .
      dockerfile: Dockerfile.superset
    container_name: superset
    restart: always
    ports:
      - "8088:8088"
    environment:
      - SUPERSET_SECRET_KEY=CHANGE_THIS_TO_SOMETHING_COMPLEX
      - SUPERSET_LOAD_EXAMPLES=false
      - PYTHONPATH=/app/pythonpath:/app/superset_init
      - WTF_CSRF_ENABLED=false
    volumes:
      - ./superset/superset_config.py:/app/pythonpath/superset_config.py
      - ./superset/init:/app/superset_init
      - superset_home:/app/superset_home
    command: >
      bash -c "
        /app/superset_init/total_fix.sh &&
        gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 'superset.app:create_app()'
      "
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8088/health"]
      interval: 30s
      timeout: 10s
      retries: 5
      start_period: 30s

volumes:
  superset_home:
    driver: local
"@

Set-Content -Path "./docker-compose-superset-only.yml" -Value $dockerCompose -Force

# 7. Build and run
Write-Host "7. Building and running Superset container..." -ForegroundColor Green
docker-compose -f docker-compose-superset-only.yml build
docker-compose -f docker-compose-superset-only.yml up -d

# 8. Wait for container to be ready
Write-Host "8. Waiting for Superset to be ready..." -ForegroundColor Yellow
Write-Host "This may take 1-2 minutes..." -ForegroundColor Yellow

# Sleep to allow container to start
Start-Sleep -Seconds 60

Write-Host "9. Verifying Superset is running..." -ForegroundColor Gray
docker-compose -f docker-compose-superset-only.yml ps

Write-Host "10. Instructions:" -ForegroundColor Cyan
Write-Host "- Wait 1-2 minutes for the container to fully initialize" -ForegroundColor White
Write-Host "- Access Superset at: http://127.0.0.1:8088" -ForegroundColor White
Write-Host "- Login with: admin / admin" -ForegroundColor White
Write-Host ""
Write-Host "If you still can't login, run this command to see error logs:" -ForegroundColor Yellow
Write-Host "docker-compose -f docker-compose-superset-only.yml logs superset" -ForegroundColor White

Write-Host ""
Write-Host "TIPS untuk masalah login yang terus berlanjut:" -ForegroundColor Magenta
Write-Host "1. Gunakan mode incognito pada browser" -ForegroundColor White
Write-Host "2. Coba akses dengan Chrome atau Firefox" -ForegroundColor White
Write-Host "3. Pastikan menggunakan http://127.0.0.1:8088 bukan localhost" -ForegroundColor White
