# Test Superset Connection Script

Write-Host "=== TESTING SUPERSET CONNECTION ===" -ForegroundColor Cyan

# Get container IP
Write-Host "Getting Superset container IP..." -ForegroundColor Yellow
$containerIP = docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' superset
if ($containerIP) {
    Write-Host "Container IP: $containerIP" -ForegroundColor Green
} else {
    Write-Host "Failed to get container IP" -ForegroundColor Red
}

# Test localhost
Write-Host "`nTesting localhost connection..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8088" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
    Write-Host "Localhost connection successful! Status code: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "Localhost connection failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Test container IP directly
Write-Host "`nTesting container IP connection..." -ForegroundColor Yellow
if ($containerIP) {
    try {
        $response = Invoke-WebRequest -Uri "http://$containerIP`:8088" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
        Write-Host "Container IP connection successful! Status code: $($response.StatusCode)" -ForegroundColor Green
    } catch {
        Write-Host "Container IP connection failed: $($_.Exception.Message)" -ForegroundColor Red
    }
}

# Test 127.0.0.1
Write-Host "`nTesting 127.0.0.1 connection..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:8088" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
    Write-Host "127.0.0.1 connection successful! Status code: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "127.0.0.1 connection failed: $($_.Exception.Message)" -ForegroundColor Red
}

# Check if container is actually running the service
Write-Host "`nChecking if the Superset service is running in the container..." -ForegroundColor Yellow
$logs = docker logs --tail 20 superset
Write-Host $logs

Write-Host "`nWaiting for Superset to start (this may take a minute)..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

# Try localhost again after waiting
Write-Host "`nTrying localhost connection again..." -ForegroundColor Yellow
try {
    $response = Invoke-WebRequest -Uri "http://localhost:8088" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
    Write-Host "Localhost connection successful! Status code: $($response.StatusCode)" -ForegroundColor Green
} catch {
    Write-Host "Localhost connection failed: $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host "`n=== SUGGESTIONS ===" -ForegroundColor Cyan
Write-Host "1. Try accessing Superset in your browser using: http://localhost:8088" -ForegroundColor White
Write-Host "2. If that fails, try: http://127.0.0.1:8088" -ForegroundColor White
Write-Host "3. If both fail, try direct IP: http://$containerIP`:8088" -ForegroundColor White
Write-Host "4. Check your firewall settings to allow connections to port 8088" -ForegroundColor White
Write-Host "5. Try disabling any antivirus temporarily to test connection" -ForegroundColor White
