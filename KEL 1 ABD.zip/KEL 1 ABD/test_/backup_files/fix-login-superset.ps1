# Script untuk memperbaiki login Superset yang gagal

Write-Host "===== MEMPERBAIKI LOGIN SUPERSET =====" -ForegroundColor Cyan

# 1. Menghentikan semua container terkait
Write-Host "Menghentikan container..." -ForegroundColor Yellow
docker-compose stop superset superset-init

# 2. Membersihkan container
Write-Host "Menghapus container..." -ForegroundColor Yellow
docker-compose rm -f superset superset-init

# 3. Buat Dockerfile baru dengan dependensi yang lengkap
Write-Host "Membuat Dockerfile dengan konfigurasi yang benar..." -ForegroundColor Yellow
@'
FROM apache/superset:latest

USER root

# Install dependencies
RUN apt-get update && \
    apt-get install -y --no-install-recommends \
    build-essential \
    gcc \
    g++ \
    libsasl2-dev \
    libkrb5-dev \
    libldap2-dev \
    python3-dev \
    default-libmysqlclient-dev

# Install Python packages
RUN pip install --upgrade pip setuptools wheel && \
    pip install flask-cors==3.0.10 \
    psycopg2-binary \
    pyathena \
    sqlalchemy==1.4.46 \
    sasl \
    thrift_sasl \
    pyhive[hive] \
    python-ldap \
    mysqlclient \
    pymssql && \
    pip cache purge

# Fix permissions
RUN mkdir -p /app/superset_home && \
    chmod -R 777 /app/superset_home

# Copy config and initialization scripts
COPY ./superset/superset_config.py /app/pythonpath/superset_config.py
COPY ./superset/init /app/superset_init

USER superset

# Set environment variables
ENV SUPERSET_SECRET_KEY="your_secret_key_here"
ENV SUPERSET_LOAD_EXAMPLES=false
ENV PYTHONPATH=/app/pythonpath:/app/superset_init
ENV FLASK_APP="superset.app:create_app()"
ENV SUPERSET_WEBSERVER_ADDRESS="0.0.0.0"
'@ | Out-File -FilePath "Dockerfile.superset" -Encoding utf8

# 4. Build image
Write-Host "Building custom Superset image..." -ForegroundColor Yellow
docker build -t custom-superset:fixed -f Dockerfile.superset .

# 5. Update docker-compose.yml
Write-Host "Creating special docker-compose file for Superset..." -ForegroundColor Yellow
Copy-Item -Path "docker-compose.yml" -Destination "docker-compose.yml.backup" -Force

# Create focused docker-compose file for Superset
@'
version: '3.7'

services:
  superset:
    image: custom-superset:fixed
    container_name: superset
    restart: always
    ports:
      - "8088:8088"
    depends_on:
      - spark-master
    environment:
      - SUPERSET_SECRET_KEY=your_secret_key_here
      - SUPERSET_LOAD_EXAMPLES=false
      - PYTHONPATH=/app/pythonpath:/app/superset_init
    volumes:
      - ./superset/superset_config.py:/app/pythonpath/superset_config.py
      - ./superset/init:/app/superset_init
      - superset_home:/app/superset_home
    command: >
      bash -c "
        superset db upgrade &&
        superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force &&
        superset init &&
        gunicorn --bind 0.0.0.0:8088 --workers 2 --worker-class gthread --threads 20 --timeout 60 'superset.app:create_app()'
      "
    networks:
      - hadoop
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8088"]
      interval: 30s
      retries: 5
      start_period: 60s
      timeout: 30s

volumes:
  superset_home:

networks:
  hadoop:
    external: true
'@ | Out-File -FilePath "docker-compose-superset.yml" -Encoding utf8

Write-Host "Starting new Superset container..." -ForegroundColor Yellow
docker-compose -f docker-compose-superset.yml up -d

Write-Host "Tunggu container untuk mulai (30 detik)..." -ForegroundColor Yellow
Start-Sleep -Seconds 30

Write-Host "======================================" -ForegroundColor Cyan
Write-Host "Container Superset telah diperbaiki dengan dependensi yang benar." -ForegroundColor Green
Write-Host "Mohon tunggu 30-60 detik agar container selesai diinisialisasi." -ForegroundColor Yellow
Write-Host "Kemudian akses Superset di: http://localhost:8088" -ForegroundColor White
Write-Host "Login dengan:" -ForegroundColor White
Write-Host "  Username: admin" -ForegroundColor White
Write-Host "  Password: admin" -ForegroundColor White
Write-Host "======================================" -ForegroundColor Cyan
