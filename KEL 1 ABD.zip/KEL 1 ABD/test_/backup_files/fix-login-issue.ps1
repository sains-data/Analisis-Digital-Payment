# Script untuk memperbaiki masalah login di Superset

Write-Host "=== SUPERSET LOGIN ISSUE FIX ===" -ForegroundColor Cyan
Write-Host ""

# Check if containers are running
$containerStatus = docker-compose ps superset
if ($containerStatus -match "Up") {
    Write-Host "Container Superset sudah berjalan." -ForegroundColor Green
} else {
    Write-Host "Container Superset tidak berjalan. Menjalankan container..." -ForegroundColor Yellow
    docker-compose up -d superset
    Start-Sleep -Seconds 30
}

# Reset database dan recreate admin
Write-Host "Mereset database dan user admin..." -ForegroundColor Yellow
docker-compose exec -T superset superset db upgrade
docker-compose exec -T superset superset fab create-admin `
    --username admin `
    --firstname Superset `
    --lastname Admin `
    --email admin@superset.com `
    --password admin `
    --force

# Reset permissions
Write-Host "Memperbaiki permission..." -ForegroundColor Yellow
docker-compose exec -T superset superset init

# Fix cache
Write-Host "Membersihkan cache..." -ForegroundColor Yellow
$cacheFixScript = @"
#!/bin/bash
rm -rf /app/superset_home/.cache/*
rm -rf /app/superset_home/superset_cache/*
mkdir -p /app/superset_home/superset_cache
chmod -R 777 /app/superset_home
"@

$cacheFixScript | Out-File -FilePath ".\superset\init\fix_cache.sh" -Encoding UTF8 -Force
docker-compose exec -T superset bash -c "chmod +x /app/superset_init/fix_cache.sh && /app/superset_init/fix_cache.sh"

# Restart dan tunggu container
Write-Host "Restart container Superset..." -ForegroundColor Yellow
docker-compose restart superset
Write-Host "Menunggu container siap (30 detik)..." -ForegroundColor Gray
Start-Sleep -Seconds 30

# Testing koneksi
Write-Host "Testing koneksi ke Superset API..." -ForegroundColor Yellow
try {
    $response = Invoke-RestMethod -Uri "http://localhost:8088/api/v1/health" -Method GET -TimeoutSec 5 -ErrorAction SilentlyContinue
    
    if ($response) {
        Write-Host "Koneksi ke Superset API berhasil!" -ForegroundColor Green
        Write-Host "Anda seharusnya bisa login dengan:" -ForegroundColor Green
        Write-Host "Username: admin" -ForegroundColor White
        Write-Host "Password: admin" -ForegroundColor White
    }
} catch {
    Write-Host "Gagal terhubung ke Superset API: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Coba akses dengan browser ke http://127.0.0.1:8088" -ForegroundColor Yellow
}

# Instruksi tambahan
Write-Host ""
Write-Host "Jika masih belum bisa login, coba langkah berikut:" -ForegroundColor Yellow
Write-Host "1. Pastikan tidak ada layanan lain yang menggunakan port 8088" -ForegroundColor White
Write-Host "2. Coba akses dengan alamat IP 127.0.0.1:8088 bukan localhost:8088" -ForegroundColor White
Write-Host "3. Pastikan file hosts memiliki entri 127.0.0.1 localhost" -ForegroundColor White
Write-Host "4. Jalankan script rebuild-and-run-superset.ps1 untuk reset total" -ForegroundColor White
