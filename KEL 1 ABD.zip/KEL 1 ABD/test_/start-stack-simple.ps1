# Script to start the entire big data stack
Write-Host "=== STARTING BIG DATA STACK ===" -ForegroundColor Cyan

# Step 1: Stop any running containers
Write-Host "Step 1: Stopping running containers..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml down
docker-compose down
docker rm -f superset 2>$null

# Step 2: Ensure network exists
Write-Host "Step 2: Ensuring hadoop network exists..." -ForegroundColor Green
docker network ls --format "{{.Name}}" | Select-String "hadoop" | Out-Null
if ($LASTEXITCODE -ne 0) {
    docker network create hadoop
}

# Step 3: Build Superset image
Write-Host "Step 3: Building Superset image..." -ForegroundColor Green
docker build -t custom-superset:fixed -f Dockerfile.superset .

# Step 4: Start Hadoop
Write-Host "Step 4: Starting Hadoop components..." -ForegroundColor Green
docker-compose up -d namenode datanode
Write-Host "Waiting for Hadoop to be ready..." -ForegroundColor Gray
Start-Sleep -Seconds 20

# Step 5: Start Spark
Write-Host "Step 5: Starting Spark components..." -ForegroundColor Green
docker-compose up -d spark-master spark-worker-1
Write-Host "Waiting for Spark to be ready..." -ForegroundColor Gray
Start-Sleep -Seconds 20

# Step 6: Start Superset
Write-Host "Step 6: Starting Superset..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml up -d
Write-Host "Waiting for Superset to initialize..." -ForegroundColor Gray
Start-Sleep -Seconds 30

# Step 7: Reset admin credentials
Write-Host "Step 7: Resetting admin credentials..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml exec -T superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force
docker-compose -f docker-compose-superset.yml exec -T superset superset init

# Step 8: Display service status
Write-Host "Step 8: Checking service status..." -ForegroundColor Green
docker ps

# Summary
Write-Host "`nBig Data stack is now running!" -ForegroundColor Cyan
Write-Host "HDFS NameNode UI : http://localhost:9870" -ForegroundColor White
Write-Host "Spark Master UI : http://localhost:8080" -ForegroundColor White
Write-Host "Superset        : http://localhost:8088 or http://127.0.0.1:8088" -ForegroundColor White
Write-Host "  - Username: admin" -ForegroundColor White
Write-Host "  - Password: admin" -ForegroundColor White

Write-Host "`nIMPORTANT NOTES:" -ForegroundColor Magenta
Write-Host "1. If you have connection issues, use browser incognito mode" -ForegroundColor Yellow
Write-Host "2. For Hive connection in Superset, use: hive://hive@spark-master:10000/default" -ForegroundColor Yellow
Write-Host "3. Run setup-superset-integration.ps1 to integrate credit card data" -ForegroundColor Yellow
