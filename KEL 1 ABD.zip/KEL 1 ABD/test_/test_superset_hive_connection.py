import requests
import json

def test_hive_connection():
    # Login to get access token
    login_data = {
        "username": "admin",
        "password": "admin",
        "provider": "db"
    }
    
    session = requests.Session()
    try:
        resp = session.post("http://localhost:8088/api/v1/security/login", json=login_data)
        
        if resp.status_code != 200:
            print(f"Login failed: {resp.status_code}")
            return False
        
        access_token = resp.json()["access_token"]
        
        headers = {
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json"
        }
        
        # Get databases
        databases_response = session.get("http://localhost:8088/api/v1/database/", headers=headers)
        if databases_response.status_code != 200:
            print(f"Failed to get databases: {databases_response.status_code}")
            return False
        
        databases = databases_response.json()["result"]
        hive_db = None
        
        for db in databases:
            if db["engine"] == "hive":
                hive_db = db
                break
        
        if not hive_db:
            print("Hive connection not found in Superset")
            return False
        
        print(f"Found Hive connection: id={hive_db['id']}, name={hive_db['database_name']}")
        
        # Test connection
        test_data = {"database_id": hive_db["id"]}
        test_response = session.post("http://localhost:8088/api/v1/database/test_connection", 
                                    json=test_data, 
                                    headers=headers)
        
        if test_response.status_code == 200:
            print("Connection test successful!")
            return True
        else:
            print(f"Connection test failed: {test_response.status_code} {test_response.text}")
            return False
    except Exception as e:
        print(f"Error testing connection: {str(e)}")
        return False

if __name__ == "__main__":
    success = test_hive_connection()
    print(f"Connection test {'succeeded' if success else 'failed'}")
