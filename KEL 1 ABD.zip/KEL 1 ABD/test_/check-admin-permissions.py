﻿# check-admin-permissions.py
from superset.app import create_app
app = create_app()
with app.app_context():
    from superset import security_manager
    from flask_appbuilder.security.sqla.models import Role
    
    admin_role = security_manager.find_role('Admin')
    if admin_role:
        print(f'Admin role exists with ID: {admin_role.id}')
        print('Permissions associated with Admin role:')
        for perm in admin_role.permissions:
            print(f'- {perm.permission.name}:{perm.view_menu.name}')
    else:
        print('Admin role not found!')
