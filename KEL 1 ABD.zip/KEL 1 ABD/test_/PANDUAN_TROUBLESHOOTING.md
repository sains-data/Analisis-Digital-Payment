# Panduan Troubleshooting Login Superset

## Masalah Umum dan Solusi

### 1. "localhost refused to connect" atau "Error 503" 

**Penyebab Potensial:**
- Container Superset belum selesai inisialisasi
- Container Superset restart berulang kali
- Port conflict pada port 8088

**Solusi:**
- Tunggu sekitar 30-60 detik setelah menjalankan container
- Coba akses menggunakan `127.0.0.1:8088` alih-alih `localhost:8088`
- Pastikan tidak ada aplikasi lain yang menggunakan port 8088
- Jalankan perintah berikut untuk melihat log error:
  ```
  docker logs superset
  ```

### 2. "Invalid login" atau "Authentication Failed" 

**Penyebab Potensial:**
- CSRF protection issues
- Cookie atau cache browser
- Kredensial admin tidak di-reset

**Solusi:**
- Gunakan mode incognito pada browser
- Pastikan `WTF_CSRF_ENABLED = False` pada superset_config.py
- Reset admin credentials:
  ```
  docker-compose -f docker-compose-superset.yml exec superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force
  ```

### 3. Masalah Dependensi SASL

**Penyebab Potensial:**
- Package `sasl`, `thrift`, atau `thrift_sasl` tidak terpasang dengan benar
- Versi package tidak kompatibel

**Solusi:**
- Pastikan versi-versi berikut digunakan dalam Dockerfile:
  - `sasl==0.3.1`
  - `thrift==0.16.0`
  - `thrift_sasl==0.4.3`
  - `pyhive[hive]==0.7.0`
  - `werkzeug==2.0.3`

### 4. Koneksi ke Spark/Hive Gagal

**Penyebab Potensial:**
- Service spark-master tidak berjalan
- Koneksi database di Superset salah

**Solusi:**
- Pastikan spark-master container berjalan:
  ```
  docker-compose ps spark-master
  ```
- Gunakan string koneksi yang benar di Superset:
  ```
  hive://hive@spark-master:10000/default
  ```
- Pastikan network antar container terkonfigurasi dengan benar

## Langkah Pemecahan Masalah Secara Sistematis

1. **Diagnosa Status Container**:
   ```
   PowerShell -ExecutionPolicy Bypass -File .\enhanced-diagnosis.ps1
   ```

2. **Cleanup dan Restart**:
   ```
   PowerShell -ExecutionPolicy Bypass -File .\cleanup-files.ps1
   PowerShell -ExecutionPolicy Bypass -File .\start-all-stack.ps1
   ```

3. **Fix Login Spesifik**:
   ```
   PowerShell -ExecutionPolicy Bypass -File .\fix-superset-login-specific.ps1
   ```

4. **Integrasi Data**:
   ```
   PowerShell -ExecutionPolicy Bypass -File .\setup-superset-integration.ps1
   ```

## Informasi Tambahan

- Admin UI Superset: http://localhost:8088 atau http://127.0.0.1:8088
- Hadoop NameNode UI: http://localhost:9870
- Spark Master UI: http://localhost:8080

Jika masalah masih berlanjut, lakukan rebuild total dengan:
```
docker system prune -a --volumes
PowerShell -ExecutionPolicy Bypass -File .\start-all-stack.ps1
```
