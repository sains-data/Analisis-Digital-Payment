# Script untuk memulai seluruh stack secara terurut
Write-Host "=== MEMULAI STACK BIG DATA LENGKAP ===" -ForegroundColor Cyan
Write-Host ""

# Step 1: Memastikan file-file yang dibutuhkan ada
Write-Host "Step 1: Verifikasi file konfigurasi..." -ForegroundColor Green
$requiredFiles = @(
    "./docker-compose.yml",
    "./docker-compose-superset.yml",
    "./Dockerfile.superset",
    "./superset/superset_config.py"
)

foreach ($file in $requiredFiles) {
    if (Test-Path $file) {
        Write-Host "  ✓ $file ditemukan" -ForegroundColor Gray
    } else {
        Write-Host "  ✗ $file tidak ditemukan!" -ForegroundColor Red
        exit
    }
}

# Step 2: Hentikan semua container yang sudah berjalan
Write-Host "`nStep 2: Menghentikan container yang sedang berjalan..." -ForegroundColor Green
docker-compose down
docker-compose -f docker-compose-superset.yml down
docker ps -a --filter "name=superset" --format "{{.ID}}" | ForEach-Object { docker rm -f $_ }

# Step 3: Memastikan network hadoop ada
Write-Host "`nStep 3: Memastikan network hadoop tersedia..." -ForegroundColor Green
$networkExists = docker network ls --format "{{.Name}}" | Select-String "hadoop"
if (-not $networkExists) {
    Write-Host "  Membuat network hadoop..." -ForegroundColor Gray
    docker network create hadoop
} else {
    Write-Host "  Network hadoop sudah ada" -ForegroundColor Gray
}

# Step 4: Build image Superset
Write-Host "`nStep 4: Membangun custom Superset image..." -ForegroundColor Green
docker build -t custom-superset:fixed -f Dockerfile.superset .

# Step 5: Memulai Hadoop components
Write-Host "`nStep 5: Memulai components Hadoop..." -ForegroundColor Green
docker-compose up -d namenode datanode

# Step 6: Tunggu hingga Hadoop siap
Write-Host "`nStep 6: Menunggu Hadoop siap..." -ForegroundColor Green
Start-Sleep -Seconds 20

# Step 7: Memulai Spark
Write-Host "`nStep 7: Memulai Spark components..." -ForegroundColor Green
docker-compose up -d spark-master spark-worker-1

# Step 8: Tunggu hingga Spark siap
Write-Host "`nStep 8: Menunggu Spark siap..." -ForegroundColor Green
Start-Sleep -Seconds 20

# Step 9: Memulai Superset
Write-Host "`nStep 9: Memulai Superset..." -ForegroundColor Green
docker-compose -f docker-compose-superset.yml up -d

# Step 10: Reset admin credentials
Write-Host "`nStep 10: Reset kredensial admin Superset (tunggu 30 detik)..." -ForegroundColor Green
Start-Sleep -Seconds 30
docker-compose -f docker-compose-superset.yml exec -T superset superset db upgrade
docker-compose -f docker-compose-superset.yml exec -T superset superset fab create-admin --username admin --firstname Superset --lastname Admin --email admin@superset.com --password admin --force
docker-compose -f docker-compose-superset.yml exec -T superset superset init

# Step 11: Verifikasi seluruh stack telah berjalan
Write-Host "`nStep 11: Verifikasi stack telah berjalan..." -ForegroundColor Green
Write-Host "  Status Hadoop:" -ForegroundColor Gray
docker-compose ps namenode datanode
Write-Host "`n  Status Spark:" -ForegroundColor Gray
docker-compose ps spark-master spark-worker-1
Write-Host "`n  Status Superset:" -ForegroundColor Gray
docker-compose -f docker-compose-superset.yml ps

Write-Host "`n=== STACK BIG DATA BERHASIL DIMULAI! ===" -ForegroundColor Cyan
Write-Host "  HDFS NameNode UI  : http://localhost:9870" -ForegroundColor White
Write-Host "  Spark Master UI  : http://localhost:8080" -ForegroundColor White
Write-Host "  Superset         : http://localhost:8088 atau http://127.0.0.1:8088" -ForegroundColor White
Write-Host "    - Username: admin" -ForegroundColor White
Write-Host "    - Password: admin" -ForegroundColor White
Write-Host ""
Write-Host "CATATAN PENTING:" -ForegroundColor Magenta
Write-Host "1. Jika terjadi masalah koneksi, gunakan mode incognito browser" -ForegroundColor Yellow
Write-Host "2. Untuk koneksi Hive di Superset, gunakan: hive://hive@spark-master:10000/default" -ForegroundColor Yellow
Write-Host "3. Jalankan script setup-superset-integration.ps1 untuk mengintegrasikan data kartu kredit" -ForegroundColor Yellow
