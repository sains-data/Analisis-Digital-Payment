import os

# Superset specific config
ROW_LIMIT = 5000
SUPERSET_WEBSERVER_PORT = 8088

# Flask App Builder configuration
# Your App secret key
SECRET_KEY = 'CHANGE_THIS_TO_SOMETHING_COMPLEX'

# Authentication settings
AUTH_TYPE = 1  # Database authentication
AUTH_USER_REGISTRATION = True
AUTH_USER_REGISTRATION_ROLE = "Admin"
AUTH_ROLE_ADMIN = "Admin"
AUTH_ROLE_PUBLIC = "Public"
SQLALCHEMY_TRACK_MODIFICATIONS = False
WTF_CSRF_ENABLED = False  # Disable CSRF for easier login troubleshooting
AUTH_PASSWORD_LOGIN = True

# The SQLAlchemy connection string
SQLALCHEMY_DATABASE_URI = 'sqlite:////app/superset_home/superset.db'

# Disabling CORS
ENABLE_CORS = False

# Caching config
CACHE_CONFIG = {
    'CACHE_TYPE': 'simple',
    'CACHE_DEFAULT_TIMEOUT': 60 * 60 * 24,
}

# Feature flags
FEATURE_FLAGS = {
    'DASHBOARD_NATIVE_FILTERS': True,
    'DASHBOARD_CROSS_FILTERS': True,
    'DASHBOARD_NATIVE_FILTERS_SET': True,
    'DASHBOARD_FILTERS_EXPERIMENTAL': True,
    'EMBEDDED_SUPERSET': True,
}

# Must have for proper connection
SUPERSET_WEBSERVER_ADDRESS = '0.0.0.0'
