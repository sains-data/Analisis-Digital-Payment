#!/bin/bash
# Script to reset Superset admin password

echo "Resetting Superset admin credentials..."

# Create admin user with default credentials
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

echo "Admin credentials have been reset to:"
echo "Username: admin"
echo "Password: admin"

# Sync permissions
superset init

echo "Superset admin reset completed!"
