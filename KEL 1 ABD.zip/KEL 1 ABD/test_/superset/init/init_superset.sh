#!/bin/bash
# Script for initializing Superset with data sources and dashboards

echo "Starting Superset initialization script..."

# Wait for Superset to be ready
echo "Waiting for Superset to be ready..."
until curl -s http://superset:8088/health > /dev/null; do
  sleep 5
done
echo "Superset is ready!"

# Connect to Hive
echo "Adding Hive data source..."
superset set-database-uri -d credit_card_db -u "hive://hive@spark-master:10000/default"

# Import datasets
echo "Importing datasets..."
# Create dataset
superset dataset create \
    --database credit_card_db \
    --table credit_card_data \
    --display-name "Credit Card Transactions"

echo "Creating base dashboards..."

# Create charts programmatically
python /app/superset_init/create_charts.py

echo "Superset initialization complete!"
