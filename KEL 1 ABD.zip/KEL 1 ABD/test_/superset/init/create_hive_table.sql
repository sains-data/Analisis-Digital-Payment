-- Create a Hive table for credit card transactions
CREATE TABLE IF NOT EXISTS credit_card_data (
    tanggal STRING,
    provinsi STRING,
    nilai_server DOUBLE,
    nilai_kartu DOUBLE,
    nilai_registered DOUBLE,
    nilai_unregistered DOUBLE,
    tahun INT,
    bulan INT,
    nama_bulan STRING,
    hari INT,
    hari_dalam_minggu STRING
) ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE;

-- Load data from HDFS into the table
LOAD DATA INPATH '/data/credit-card-data/DataFixABD.csv' OVERWRITE INTO TABLE credit_card_data;
