#!/bin/bash
# Script to create Hive table and load data from HDFS

echo "Creating Hive table for credit card data..."

# Wait for Hive to be ready
until echo "show databases;" | beeline -u "jdbc:hive2://spark-master:10000" -n hive -p hive > /dev/null 2>&1; do
  echo "Waiting for Hive to be ready..."
  sleep 5
done

# Run the SQL script
echo "Running SQL script to create table and load data..."
beeline -u "jdbc:hive2://spark-master:10000" -n hive -p hive -f /app/superset_init/create_hive_table.sql

echo "Hive table creation completed!"
