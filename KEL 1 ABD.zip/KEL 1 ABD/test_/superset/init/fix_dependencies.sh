﻿#!/bin/bash
echo "Installing required dependencies..."
pip install flask-cors==3.0.10
pip install psycopg2-binary
pip install pyathena
pip install pyhive[hive]==0.7.0
pip install sasl==0.3.1 thrift==0.16.0 thrift_sasl==0.4.3
pip install sqlalchemy==1.4.46
pip install werkzeug==2.0.3
pip install flask==2.0.3
pip install flask-wtf==0.15.1
pip install wtforms==2.3.3

echo "Fixing permissions..."
chmod -R 777 /app/superset_home

echo "Running DB upgrade..."
superset db upgrade

echo "Creating admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

echo "Initializing..."
superset init

echo "All fixes applied!"
