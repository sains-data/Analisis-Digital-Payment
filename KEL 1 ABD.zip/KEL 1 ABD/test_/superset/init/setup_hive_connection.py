import os
from superset import db
from superset.models.core import Database

# Host harus sesuai dengan nama container Spark
HIVE_HOST = "spark-master"
HIVE_PORT = 10000
HIVE_DATABASE = "default"
HIVE_USER = "hive"

# Membuat atau memperbarui koneksi ke Hive
hive_connection_string = f"hive://{HIVE_USER}@{HIVE_HOST}:{HIVE_PORT}/{HIVE_DATABASE}"
database = db.session.query(Database).filter_by(database_name="Credit Card Analytics").first()

if not database:
    # Jika database belum ada, buat baru
    database = Database(
        database_name="Credit Card Analytics",
        sqlalchemy_uri=hive_connection_string,
        cache_timeout=0,
        expose_in_sqllab=True,
        allow_ctas=True,
        allow_cvas=True,
        allow_dml=True,
        allow_multi_schema_metadata_fetch=True
    )
    db.session.add(database)
else:
    # Jika sudah ada, perbarui URI dan konfigurasi
    database.sqlalchemy_uri = hive_connection_string
    database.expose_in_sqllab = True
    database.allow_ctas = True
    database.allow_cvas = True
    database.allow_dml = True
    database.allow_multi_schema_metadata_fetch = True

# Simpan perubahan
db.session.commit()

print("Database connection 'Credit Card Analytics' successfully configured!")
