﻿#!/bin/bash
echo "Beginning comprehensive Superset fix..."

# Install dependencies
echo "Installing dependencies..."
pip install --upgrade pip setuptools wheel
pip install flask-cors==3.0.10
pip install psycopg2-binary
pip install pyathena
pip install sqlalchemy==1.4.46
pip install sasl thrift_sasl
pip install pyhive[hive]
pip install pymysql

# Fix permissions
echo "Setting correct permissions..."
chmod -R 777 /app/superset_home

# Remove any existing database
echo "Removing any existing database..."
rm -f /app/superset_home/superset.db
rm -rf /app/superset_home/.cache
rm -rf /app/superset_home/superset_cache
mkdir -p /app/superset_home/superset_cache

# Initialize database
echo "Initializing database from scratch..."
superset db upgrade

# Create admin user
echo "Creating admin user..."
superset fab create-admin \
    --username admin \
    --firstname Superset \
    --lastname Admin \
    --email admin@superset.com \
    --password admin \
    --force

# Initialize
echo "Initializing Superset..."
superset init

# Load examples (optional)
# superset load_examples

echo "Fix complete. Ready to access Superset!"
