#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Script to create charts and dashboards in Superset based on the 
credit card analysis we've done in Jupyter notebooks
"""

import json
import requests
import time
import os
from superset import db
from superset.models.slice import Slice
from superset.models.dashboard import Dashboard

print("Starting creation of charts and dashboards...")

# Base configuration
BASE_URL = "http://superset:8088/api/v1"
USERNAME = "admin"
PASSWORD = "admin"

# Get access token
def get_access_token():
    login_url = f"{BASE_URL}/security/login"
    login_data = {
        "username": USERNAME,
        "password": PASSWORD,
        "provider": "db"
    }
    
    response = requests.post(login_url, json=login_data)
    token = response.json().get("access_token")
    return token

# Get headers with authorization
def get_headers():
    token = get_access_token()
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

# Get dataset ID
def get_dataset_id(dataset_name="Credit Card Transactions"):
    datasets_url = f"{BASE_URL}/dataset/"
    headers = get_headers()
    response = requests.get(datasets_url, headers=headers)
    datasets = response.json().get("result", [])
    
    for dataset in datasets:
        if dataset["table_name"] == "credit_card_data":
            return dataset["id"]
    
    return None

# Create monthly trends chart
def create_monthly_trend_chart(dataset_id):
    chart_data = {
        "datasource_id": dataset_id,
        "datasource_type": "table",
        "slice_name": "Monthly Transaction Trends",
        "viz_type": "line",
        "params": json.dumps({
            "metrics": [
                {"expressionType": "SQL", "sqlExpression": "AVG(Nilai_Server)", "column": None, "aggregate": None, "label": "Average Server Value"},
                {"expressionType": "SQL", "sqlExpression": "AVG(Nilai_Kartu)", "column": None, "aggregate": None, "label": "Average Card Value"}
            ],
            "columns": ["bulan", "tahun"],
            "adhoc_filters": [],
            "row_limit": 10000,
            "time_grain_sqla": "P1M",
            "order_desc": True,
            "color_scheme": "supersetColors",
            "x_axis_format": ",d",
            "y_axis_format": ".4~f",
            "show_legend": True
        })
    }
    
    chart_url = f"{BASE_URL}/chart/"
    headers = get_headers()
    response = requests.post(chart_url, json=chart_data, headers=headers)
    return response.json()

# Create daily breakdown chart
def create_daily_breakdown_chart(dataset_id):
    chart_data = {
        "datasource_id": dataset_id,
        "datasource_type": "table",
        "slice_name": "Daily Transaction Patterns",
        "viz_type": "bar",
        "params": json.dumps({
            "metrics": [{"expressionType": "SQL", "sqlExpression": "AVG(Nilai_Server)", "column": None, "aggregate": None, "label": "Average Server Value"}],
            "groupby": ["hari_dalam_minggu"],
            "adhoc_filters": [],
            "row_limit": 7,
            "color_scheme": "supersetColors",
            "show_legend": True,
            "y_axis_format": ".4~f"
        })
    }
    
    chart_url = f"{BASE_URL}/chart/"
    headers = get_headers()
    response = requests.post(chart_url, json=chart_data, headers=headers)
    return response.json()

# Create outlier detection chart
def create_outlier_chart(dataset_id):
    chart_data = {
        "datasource_id": dataset_id,
        "datasource_type": "table",
        "slice_name": "Outlier Analysis",
        "viz_type": "scatter",
        "params": json.dumps({
            "metrics": [
                {"expressionType": "SQL", "sqlExpression": "Nilai_Server", "column": None, "aggregate": None, "label": "Server Value"}
            ],
            "x_axis": {"expressionType": "SQL", "sqlExpression": "tanggal", "column": None, "aggregate": None, "label": "Date"},
            "adhoc_filters": [],
            "color_scheme": "supersetColors",
            "show_legend": True,
            "y_axis_format": ".4~f"
        })
    }
    
    chart_url = f"{BASE_URL}/chart/"
    headers = get_headers()
    response = requests.post(chart_url, json=chart_data, headers=headers)
    return response.json()

# Create correlation heatmap
def create_correlation_heatmap(dataset_id):
    chart_data = {
        "datasource_id": dataset_id,
        "datasource_type": "table",
        "slice_name": "Transaction Metrics Correlation",
        "viz_type": "heatmap",
        "params": json.dumps({
            "all_columns_x": ["Nilai_Server", "Nilai_Kartu", "Nilai_Registered", "Nilai_Unregistered"],
            "all_columns_y": ["Nilai_Server", "Nilai_Kartu", "Nilai_Registered", "Nilai_Unregistered"],
            "metric": {"expressionType": "SQL", "sqlExpression": "CORR(x, y)", "column": None, "aggregate": None},
            "adhoc_filters": [],
            "row_limit": 10000,
            "linear_color_scheme": "blue_white_yellow",
            "y_axis_format": ".4~f"
        })
    }
    
    chart_url = f"{BASE_URL}/chart/"
    headers = get_headers()
    response = requests.post(chart_url, json=chart_data, headers=headers)
    return response.json()

# Create dashboard with charts
def create_dashboard(chart_ids):
    dashboard_data = {
        "dashboard_title": "Credit Card Transaction Analysis",
        "published": True,
        "css": "",
        "json_metadata": json.dumps({
            "positions": {
                str(chart_ids[0]): {
                    "col": 0,
                    "row": 0,
                    "size_x": 12,
                    "size_y": 6
                },
                str(chart_ids[1]): {
                    "col": 0,
                    "row": 6,
                    "size_x": 6,
                    "size_y": 6
                },
                str(chart_ids[2]): {
                    "col": 6,
                    "row": 6,
                    "size_x": 6,
                    "size_y": 6
                },
                str(chart_ids[3]): {
                    "col": 0,
                    "row": 12,
                    "size_x": 12,
                    "size_y": 6
                }
            }
        })
    }
    
    dashboard_url = f"{BASE_URL}/dashboard/"
    headers = get_headers()
    response = requests.post(dashboard_url, json=dashboard_data, headers=headers)
    
    # Add charts to dashboard
    dashboard_id = response.json().get("id")
    if dashboard_id:
        for chart_id in chart_ids:
            chart_dashboard_url = f"{BASE_URL}/dashboard/{dashboard_id}/charts"
            chart_data = {
                "chart_ids": [chart_id]
            }
            requests.post(chart_dashboard_url, json=chart_data, headers=headers)
    
    return response.json()

# Main execution function
def main():
    try:
        dataset_id = get_dataset_id()
        if not dataset_id:
            print("Could not find the Credit Card Transactions dataset.")
            return
        
        print(f"Creating charts for dataset ID: {dataset_id}")
        
        # Create charts
        monthly_trend = create_monthly_trend_chart(dataset_id)
        daily_breakdown = create_daily_breakdown_chart(dataset_id)
        outlier_chart = create_outlier_chart(dataset_id)
        correlation_chart = create_correlation_heatmap(dataset_id)
        
        # Extract chart IDs
        chart_ids = [
            monthly_trend.get("id"),
            daily_breakdown.get("id"),
            outlier_chart.get("id"),
            correlation_chart.get("id")
        ]
        
        # Filter out any None values in case some charts failed
        chart_ids = [chart_id for chart_id in chart_ids if chart_id]
        
        if chart_ids:
            # Create dashboard with charts
            dashboard = create_dashboard(chart_ids)
            print(f"Dashboard created with ID: {dashboard.get('id')}")
        else:
            print("No charts were created successfully.")
    
    except Exception as e:
        print(f"Error creating charts and dashboard: {str(e)}")

if __name__ == "__main__":
    # Wait a bit for Superset API to be fully ready
    time.sleep(10)
    main()
