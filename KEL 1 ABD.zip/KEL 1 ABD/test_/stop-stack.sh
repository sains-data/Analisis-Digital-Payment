#!/bin/bash
# Script to stop the entire data analysis stack

echo "Stopping Hadoop, Spark, and Superset stack..."

# Stop all services
docker-compose down

echo "Data stack has been stopped"
