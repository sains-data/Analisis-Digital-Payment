from pyspark.sql import SparkSession

# Initialize Spark session with Hive support
spark = SparkSession.builder \
    .appName("Create Digital Payments Table") \
    .config("spark.sql.warehouse.dir", "/user/hive/warehouse") \
    .enableHiveSupport() \
    .getOrCreate()

# Read the CSV file
print("Reading CSV file...")
df = spark.read.option("header", "true") \
    .option("inferSchema", "true") \
    .csv("/user/hive/warehouse/DataFixABD.csv")

# Print schema and sample data
print("Schema:")
df.printSchema()
print("\nSample data:")
df.show(5)

# Create Hive table
print("Creating Hive table...")
table_name = "digital_payments"
df.write.mode("overwrite").saveAsTable(table_name)

# Verify table was created
print("Verifying table creation...")
spark.sql("SHOW TABLES").show()

# Count rows in the table
count = spark.sql(f"SELECT COUNT(*) FROM {table_name}").collect()[0][0]
print(f"\nTotal rows in {table_name}: {count}")

# Stop Spark session
spark.stop()
