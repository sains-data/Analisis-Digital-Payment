import requests

def test_superset_connection():
    try:
        # Try to access Superset's health endpoint
        response = requests.get('http://localhost:8088/health')
        
        # Print response status and body
        print(f"Status code: {response.status_code}")
        print(f"Response body: {response.text}")
        
        if response.status_code == 200:
            print("Superset is up and running!")
        else:
            print("Superset responded but returned non-200 status code.")
    except requests.exceptions.ConnectionError:
        print("Could not connect to Superset. Make sure it's running and accessible.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == "__main__":
    test_superset_connection()
