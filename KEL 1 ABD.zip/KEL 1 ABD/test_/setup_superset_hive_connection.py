import json
import os
import requests
from superset.app import create_app

app = create_app()
with app.app_context():
    from superset import db
    from superset.connectors.sqla.models import SqlaTable
    from superset.models.core import Database

    # Login to get session for API calls
    print("Logging in to Superset...")
    login_data = {
        "username": "admin",
        "password": "admin",
        "provider": "db"
    }
    
    session = requests.Session()
    resp = session.post("http://localhost:8088/api/v1/security/login", json=login_data)
    
    if resp.status_code != 200:
        print(f"Login failed: {resp.status_code} {resp.text}")
        exit(1)
    
    access_token = resp.json()["access_token"]
    refresh_token = resp.json()["refresh_token"]
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }

    # Define connection parameters
    HIVE_HOST = "spark-master"
    HIVE_PORT = 10000
    HIVE_DATABASE = "default"
    HIVE_USER = "hive"
    HIVE_PASSWORD = "hive"
    
    # Connection string format for Hive
    hive_connection_string = f"hive://{HIVE_USER}:{HIVE_PASSWORD}@{HIVE_HOST}:{HIVE_PORT}/{HIVE_DATABASE}"

    # Check if connection already exists
    print("Checking if Hive connection exists...")
    databases_response = session.get("http://localhost:8088/api/v1/database/", headers=headers)
    
    if databases_response.status_code != 200:
        print(f"Failed to get databases: {databases_response.status_code} {databases_response.text}")
        exit(1)
        
    databases = databases_response.json()["result"]
    
    existing_connection = None
    for db in databases:
        if "hive" in db["sqlalchemy_uri"].lower():
            existing_connection = db
            break
    
    if existing_connection:
        print(f"Connection to Hive already exists with id {existing_connection['id']}")
        # Update the existing connection
        update_data = {
            "database_name": "Hive",
            "sqlalchemy_uri": hive_connection_string
        }
        update_response = session.put(
            f"http://localhost:8088/api/v1/database/{existing_connection['id']}",
            json=update_data,
            headers=headers
        )
        if update_response.status_code == 200:
            print("Updated connection to Hive")
            connection_id = existing_connection['id']
        else:
            print(f"Failed to update connection: {update_response.status_code} {update_response.text}")
            exit(1)
    else:
        print("Creating new connection to Hive...")
        
        # Create the connection
        connection_data = {
            "database_name": "Hive",
            "engine": "hive",
            "configuration_method": "sqlalchemy_form",
            "sqlalchemy_uri": hive_connection_string,
            "impersonate_user": False,
            "allow_run_async": True,
            "allow_dml": True,
            "allow_file_upload": False,
            "expose_in_sqllab": True,
            "allow_ctas": True,
            "allow_cvas": True,
            "extra": json.dumps({"metadata_params": {}, "engine_params": {}})
        }
        
        create_response = session.post("http://localhost:8088/api/v1/database/", json=connection_data, headers=headers)
        
        if create_response.status_code == 201:
            print("Connection to Hive created successfully!")
            connection_id = create_response.json()["id"]
        else:
            print(f"Failed to create connection: {create_response.status_code} {create_response.text}")
            exit(1)

    # Test the connection
    print("Testing connection to Hive...")
    test_data = {"database_id": connection_id}
    test_response = session.post(
        "http://localhost:8088/api/v1/database/test_connection", 
        json=test_data,
        headers=headers
    )
    
    if test_response.status_code == 200:
        print("Connection to Hive is working!")
    else:
        print(f"Connection test failed: {test_response.status_code} {test_response.text}")
        print("Connection might still work, proceeding anyway...")

    # Create dataset for credit_card_data
    print("Creating dataset for credit_card_data...")
    
    # Check if dataset already exists
    datasets_response = session.get(f"http://localhost:8088/api/v1/dataset/", headers=headers)
    datasets = datasets_response.json()["result"]
    
    existing_dataset = None
    for dataset in datasets:
        if dataset["table_name"] == "credit_card_data":
            existing_dataset = dataset
            break
    
    if existing_dataset:
        print(f"Dataset 'credit_card_data' already exists with id {existing_dataset['id']}")
    else:
        print("Creating new dataset for 'credit_card_data'...")
        
        # Create the dataset
        dataset_data = {
            "database": connection_id,
            "schema": "default",
            "table_name": "credit_card_data"
        }
        
        dataset_response = session.post("http://localhost:8088/api/v1/dataset/", json=dataset_data, headers=headers)
        
        if dataset_response.status_code == 201:
            print("Dataset 'credit_card_data' created successfully!")
            dataset_id = dataset_response.json()["id"]
        else:
            print(f"Failed to create dataset: {dataset_response.status_code} {dataset_response.text}")
            exit(1)

    print("Setup completed successfully!")
