#!/bin/bash
# File list yang akan dihapus (file-file duplikat dan tidak digunakan)

# Backup folder terlebih dahulu
mkdir -p ./backup_files
cp ./fix-login-specific.ps1 ./backup_files/
cp ./fix-login-issue.ps1 ./backup_files/
cp ./fix-login-superset.ps1 ./backup_files/
cp ./fix-login-superset.sh ./backup_files/
cp ./fix-superset-sasl.ps1 ./backup_files/
cp ./fix-superset-sasl.sh ./backup_files/
cp ./fix-superset-standalone.ps1 ./backup_files/
cp ./fix-superset-standalone.sh ./backup_files/
cp ./rebuild-and-run-superset.ps1 ./backup_files/
cp ./rebuild-superset.ps1 ./backup_files/
cp ./rebuild-superset.sh ./backup_files/
cp ./reset-superset.ps1 ./backup_files/
cp ./test-superset-connection.ps1 ./backup_files/
cp ./total-superset-fix.ps1 ./backup_files/
cp ./total-superset-fix.sh ./backup_files/
cp ./fix-auth-only.ps1 ./backup_files/
cp ./update-superset-command.ps1 ./backup_files/
cp ./superset-rebuild-guide.ps1 ./backup_files/

# Hapus file yang tidak diperlukan
rm ./fix-login-specific.ps1
rm ./fix-login-issue.ps1
rm ./fix-login-superset.ps1
rm ./fix-login-superset.sh
rm ./fix-superset-sasl.ps1
rm ./fix-superset-sasl.sh
rm ./fix-superset-standalone.ps1
rm ./fix-superset-standalone.sh
rm ./rebuild-and-run-superset.ps1
rm ./rebuild-superset.ps1
rm ./rebuild-superset.sh
rm ./reset-superset.ps1
rm ./test-superset-connection.ps1
rm ./total-superset-fix.ps1
rm ./total-superset-fix.sh
rm ./fix-auth-only.ps1
rm ./update-superset-command.ps1
rm ./superset-rebuild-guide.ps1

echo "File-file duplikat telah dibackup ke ./backup_files dan dihapus dari direktori utama"
